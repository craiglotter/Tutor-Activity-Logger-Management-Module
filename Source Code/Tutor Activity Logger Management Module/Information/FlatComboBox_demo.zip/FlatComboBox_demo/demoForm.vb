Public Class demoForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents lnkAbout As System.Windows.Forms.LinkLabel
    Friend WithEvents Timer1 As System.Windows.Forms.Timer
    Friend WithEvents chkEnabled As System.Windows.Forms.CheckBox
    Friend WithEvents lblAbout As System.Windows.Forms.Label
    Friend WithEvents Panel1 As System.Windows.Forms.Panel
    Friend WithEvents Panel3 As System.Windows.Forms.Panel
    Friend WithEvents Label2 As System.Windows.Forms.Label
    Friend WithEvents Label3 As System.Windows.Forms.Label
    Friend WithEvents lblNormal As System.Windows.Forms.Label
    Friend WithEvents Label1 As System.Windows.Forms.Label
    Friend WithEvents Panel2 As System.Windows.Forms.Panel
    Friend WithEvents Panel4 As System.Windows.Forms.Panel
    Friend WithEvents Label4 As System.Windows.Forms.Label
    Friend WithEvents Panel5 As System.Windows.Forms.Panel
    Friend WithEvents Panel6 As System.Windows.Forms.Panel
    Friend WithEvents Label5 As System.Windows.Forms.Label
    Friend WithEvents Panel7 As System.Windows.Forms.Panel
    Friend WithEvents Panel8 As System.Windows.Forms.Panel
    Friend WithEvents Label7 As System.Windows.Forms.Label
    Friend WithEvents Label8 As System.Windows.Forms.Label
    Friend WithEvents Label9 As System.Windows.Forms.Label
    Friend WithEvents Label10 As System.Windows.Forms.Label
    Friend WithEvents Panel13 As System.Windows.Forms.Panel
    Friend WithEvents Panel14 As System.Windows.Forms.Panel
    Friend WithEvents Panel15 As System.Windows.Forms.Panel
    Friend WithEvents Panel16 As System.Windows.Forms.Panel
    Friend WithEvents Panel17 As System.Windows.Forms.Panel
    Friend WithEvents Panel18 As System.Windows.Forms.Panel
    Friend WithEvents Panel19 As System.Windows.Forms.Panel
    Friend WithEvents Panel20 As System.Windows.Forms.Panel
    Friend WithEvents FlatComboBox1 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox2 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox3 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox4 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox5 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox6 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox7 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox8 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox9 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox10 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox11 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox12 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox13 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox14 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox15 As FlatCombo.FlatComboBox
    Friend WithEvents FlatComboBox16 As FlatCombo.FlatComboBox
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Me.components = New System.ComponentModel.Container
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(demoForm))
        Me.lblAbout = New System.Windows.Forms.Label
        Me.lnkAbout = New System.Windows.Forms.LinkLabel
        Me.Timer1 = New System.Windows.Forms.Timer(Me.components)
        Me.chkEnabled = New System.Windows.Forms.CheckBox
        Me.Panel1 = New System.Windows.Forms.Panel
        Me.FlatComboBox1 = New FlatCombo.FlatComboBox
        Me.Panel3 = New System.Windows.Forms.Panel
        Me.FlatComboBox9 = New FlatCombo.FlatComboBox
        Me.lblNormal = New System.Windows.Forms.Label
        Me.Label2 = New System.Windows.Forms.Label
        Me.Label3 = New System.Windows.Forms.Label
        Me.Label1 = New System.Windows.Forms.Label
        Me.Panel2 = New System.Windows.Forms.Panel
        Me.FlatComboBox12 = New FlatCombo.FlatComboBox
        Me.Panel4 = New System.Windows.Forms.Panel
        Me.FlatComboBox2 = New FlatCombo.FlatComboBox
        Me.Label4 = New System.Windows.Forms.Label
        Me.Panel5 = New System.Windows.Forms.Panel
        Me.FlatComboBox13 = New FlatCombo.FlatComboBox
        Me.Panel6 = New System.Windows.Forms.Panel
        Me.FlatComboBox3 = New FlatCombo.FlatComboBox
        Me.Label5 = New System.Windows.Forms.Label
        Me.Panel7 = New System.Windows.Forms.Panel
        Me.FlatComboBox14 = New FlatCombo.FlatComboBox
        Me.Panel8 = New System.Windows.Forms.Panel
        Me.FlatComboBox4 = New FlatCombo.FlatComboBox
        Me.Label7 = New System.Windows.Forms.Label
        Me.Label8 = New System.Windows.Forms.Label
        Me.Label9 = New System.Windows.Forms.Label
        Me.Label10 = New System.Windows.Forms.Label
        Me.Panel13 = New System.Windows.Forms.Panel
        Me.FlatComboBox15 = New FlatCombo.FlatComboBox
        Me.Panel14 = New System.Windows.Forms.Panel
        Me.FlatComboBox5 = New FlatCombo.FlatComboBox
        Me.Panel15 = New System.Windows.Forms.Panel
        Me.FlatComboBox16 = New FlatCombo.FlatComboBox
        Me.Panel16 = New System.Windows.Forms.Panel
        Me.FlatComboBox6 = New FlatCombo.FlatComboBox
        Me.Panel17 = New System.Windows.Forms.Panel
        Me.FlatComboBox11 = New FlatCombo.FlatComboBox
        Me.Panel18 = New System.Windows.Forms.Panel
        Me.FlatComboBox7 = New FlatCombo.FlatComboBox
        Me.Panel19 = New System.Windows.Forms.Panel
        Me.FlatComboBox10 = New FlatCombo.FlatComboBox
        Me.Panel20 = New System.Windows.Forms.Panel
        Me.FlatComboBox8 = New FlatCombo.FlatComboBox
        Me.Panel1.SuspendLayout()
        Me.Panel3.SuspendLayout()
        Me.Panel2.SuspendLayout()
        Me.Panel4.SuspendLayout()
        Me.Panel5.SuspendLayout()
        Me.Panel6.SuspendLayout()
        Me.Panel7.SuspendLayout()
        Me.Panel8.SuspendLayout()
        Me.Panel13.SuspendLayout()
        Me.Panel14.SuspendLayout()
        Me.Panel15.SuspendLayout()
        Me.Panel16.SuspendLayout()
        Me.Panel17.SuspendLayout()
        Me.Panel18.SuspendLayout()
        Me.Panel19.SuspendLayout()
        Me.Panel20.SuspendLayout()
        Me.SuspendLayout()
        '
        'lblAbout
        '
        Me.lblAbout.Location = New System.Drawing.Point(344, 192)
        Me.lblAbout.Name = "lblAbout"
        Me.lblAbout.Size = New System.Drawing.Size(208, 23)
        Me.lblAbout.TabIndex = 1
        Me.lblAbout.Text = "FlatCombo, created by Devinck Wouter"
        Me.lblAbout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lnkAbout
        '
        Me.lnkAbout.Location = New System.Drawing.Point(544, 192)
        Me.lnkAbout.Name = "lnkAbout"
        Me.lnkAbout.Size = New System.Drawing.Size(40, 23)
        Me.lnkAbout.TabIndex = 2
        Me.lnkAbout.TabStop = True
        Me.lnkAbout.Text = "About"
        Me.lnkAbout.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'chkEnabled
        '
        Me.chkEnabled.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.chkEnabled.Location = New System.Drawing.Point(24, 24)
        Me.chkEnabled.Name = "chkEnabled"
        Me.chkEnabled.Size = New System.Drawing.Size(64, 16)
        Me.chkEnabled.TabIndex = 5
        Me.chkEnabled.Text = "Enabled"
        '
        'Panel1
        '
        Me.Panel1.BackColor = System.Drawing.SystemColors.Control
        Me.Panel1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel1.Controls.Add(Me.FlatComboBox1)
        Me.Panel1.Location = New System.Drawing.Point(111, 54)
        Me.Panel1.Name = "Panel1"
        Me.Panel1.Size = New System.Drawing.Size(117, 31)
        Me.Panel1.TabIndex = 6
        '
        'FlatComboBox1
        '
        Me.FlatComboBox1.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox1.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox1.Name = "FlatComboBox1"
        Me.FlatComboBox1.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox1.TabIndex = 41
        '
        'Panel3
        '
        Me.Panel3.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel3.Controls.Add(Me.FlatComboBox9)
        Me.Panel3.Location = New System.Drawing.Point(344, 54)
        Me.Panel3.Name = "Panel3"
        Me.Panel3.Size = New System.Drawing.Size(117, 31)
        Me.Panel3.TabIndex = 7
        '
        'FlatComboBox9
        '
        Me.FlatComboBox9.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox9.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox9.Name = "FlatComboBox9"
        Me.FlatComboBox9.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox9.TabIndex = 42
        '
        'lblNormal
        '
        Me.lblNormal.BackColor = System.Drawing.Color.White
        Me.lblNormal.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.lblNormal.Location = New System.Drawing.Point(8, 54)
        Me.lblNormal.Name = "lblNormal"
        Me.lblNormal.Size = New System.Drawing.Size(104, 31)
        Me.lblNormal.TabIndex = 11
        Me.lblNormal.Text = "Normal"
        Me.lblNormal.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Label2
        '
        Me.Label2.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Label2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label2.Location = New System.Drawing.Point(344, 8)
        Me.Label2.Name = "Label2"
        Me.Label2.Size = New System.Drawing.Size(233, 24)
        Me.Label2.TabIndex = 12
        Me.Label2.Text = "Office 2003"
        Me.Label2.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label3
        '
        Me.Label3.BackColor = System.Drawing.SystemColors.Control
        Me.Label3.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label3.Location = New System.Drawing.Point(111, 8)
        Me.Label3.Name = "Label3"
        Me.Label3.Size = New System.Drawing.Size(233, 24)
        Me.Label3.TabIndex = 13
        Me.Label3.Text = "Office XP"
        Me.Label3.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label1
        '
        Me.Label1.BackColor = System.Drawing.Color.Transparent
        Me.Label1.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label1.Location = New System.Drawing.Point(8, 84)
        Me.Label1.Name = "Label1"
        Me.Label1.Size = New System.Drawing.Size(104, 31)
        Me.Label1.TabIndex = 17
        Me.Label1.Text = "Right to left"
        Me.Label1.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel2
        '
        Me.Panel2.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel2.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel2.Controls.Add(Me.FlatComboBox12)
        Me.Panel2.Location = New System.Drawing.Point(344, 84)
        Me.Panel2.Name = "Panel2"
        Me.Panel2.Size = New System.Drawing.Size(117, 31)
        Me.Panel2.TabIndex = 16
        '
        'FlatComboBox12
        '
        Me.FlatComboBox12.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox12.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox12.Name = "FlatComboBox12"
        Me.FlatComboBox12.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox12.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox12.TabIndex = 42
        '
        'Panel4
        '
        Me.Panel4.BackColor = System.Drawing.SystemColors.Control
        Me.Panel4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel4.Controls.Add(Me.FlatComboBox2)
        Me.Panel4.Location = New System.Drawing.Point(111, 84)
        Me.Panel4.Name = "Panel4"
        Me.Panel4.Size = New System.Drawing.Size(117, 31)
        Me.Panel4.TabIndex = 15
        '
        'FlatComboBox2
        '
        Me.FlatComboBox2.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox2.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox2.Name = "FlatComboBox2"
        Me.FlatComboBox2.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox2.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox2.TabIndex = 42
        '
        'Label4
        '
        Me.Label4.BackColor = System.Drawing.Color.Transparent
        Me.Label4.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label4.Location = New System.Drawing.Point(8, 114)
        Me.Label4.Name = "Label4"
        Me.Label4.Size = New System.Drawing.Size(104, 38)
        Me.Label4.TabIndex = 20
        Me.Label4.Text = "Big font"
        Me.Label4.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel5
        '
        Me.Panel5.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel5.Controls.Add(Me.FlatComboBox13)
        Me.Panel5.Location = New System.Drawing.Point(344, 114)
        Me.Panel5.Name = "Panel5"
        Me.Panel5.Size = New System.Drawing.Size(117, 38)
        Me.Panel5.TabIndex = 19
        '
        'FlatComboBox13
        '
        Me.FlatComboBox13.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox13.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox13.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox13.Name = "FlatComboBox13"
        Me.FlatComboBox13.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox13.TabIndex = 42
        '
        'Panel6
        '
        Me.Panel6.BackColor = System.Drawing.SystemColors.Control
        Me.Panel6.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel6.Controls.Add(Me.FlatComboBox3)
        Me.Panel6.Location = New System.Drawing.Point(111, 114)
        Me.Panel6.Name = "Panel6"
        Me.Panel6.Size = New System.Drawing.Size(117, 38)
        Me.Panel6.TabIndex = 18
        '
        'FlatComboBox3
        '
        Me.FlatComboBox3.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox3.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox3.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox3.Name = "FlatComboBox3"
        Me.FlatComboBox3.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox3.TabIndex = 42
        '
        'Label5
        '
        Me.Label5.BackColor = System.Drawing.Color.Transparent
        Me.Label5.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label5.Location = New System.Drawing.Point(8, 151)
        Me.Label5.Name = "Label5"
        Me.Label5.Size = New System.Drawing.Size(104, 38)
        Me.Label5.TabIndex = 23
        Me.Label5.Text = "Big font +                          Right to Left"
        Me.Label5.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'Panel7
        '
        Me.Panel7.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel7.Controls.Add(Me.FlatComboBox14)
        Me.Panel7.Location = New System.Drawing.Point(344, 151)
        Me.Panel7.Name = "Panel7"
        Me.Panel7.Size = New System.Drawing.Size(117, 38)
        Me.Panel7.TabIndex = 22
        '
        'FlatComboBox14
        '
        Me.FlatComboBox14.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox14.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox14.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox14.Name = "FlatComboBox14"
        Me.FlatComboBox14.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox14.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox14.TabIndex = 42
        '
        'Panel8
        '
        Me.Panel8.BackColor = System.Drawing.SystemColors.Control
        Me.Panel8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel8.Controls.Add(Me.FlatComboBox4)
        Me.Panel8.Location = New System.Drawing.Point(111, 151)
        Me.Panel8.Name = "Panel8"
        Me.Panel8.Size = New System.Drawing.Size(117, 38)
        Me.Panel8.TabIndex = 21
        '
        'FlatComboBox4
        '
        Me.FlatComboBox4.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox4.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox4.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox4.Name = "FlatComboBox4"
        Me.FlatComboBox4.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox4.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox4.TabIndex = 42
        '
        'Label7
        '
        Me.Label7.BackColor = System.Drawing.SystemColors.Control
        Me.Label7.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label7.Location = New System.Drawing.Point(111, 31)
        Me.Label7.Name = "Label7"
        Me.Label7.Size = New System.Drawing.Size(117, 23)
        Me.Label7.TabIndex = 27
        Me.Label7.Text = "DropDown"
        Me.Label7.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label8
        '
        Me.Label8.BackColor = System.Drawing.SystemColors.Control
        Me.Label8.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label8.Location = New System.Drawing.Point(227, 31)
        Me.Label8.Name = "Label8"
        Me.Label8.Size = New System.Drawing.Size(117, 23)
        Me.Label8.TabIndex = 28
        Me.Label8.Text = "DropDownList"
        Me.Label8.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label9
        '
        Me.Label9.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Label9.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label9.Location = New System.Drawing.Point(460, 31)
        Me.Label9.Name = "Label9"
        Me.Label9.Size = New System.Drawing.Size(117, 23)
        Me.Label9.TabIndex = 30
        Me.Label9.Text = "DropDownList"
        Me.Label9.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Label10
        '
        Me.Label10.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Label10.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Label10.Location = New System.Drawing.Point(344, 31)
        Me.Label10.Name = "Label10"
        Me.Label10.Size = New System.Drawing.Size(117, 23)
        Me.Label10.TabIndex = 29
        Me.Label10.Text = "DropDown"
        Me.Label10.TextAlign = System.Drawing.ContentAlignment.MiddleCenter
        '
        'Panel13
        '
        Me.Panel13.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel13.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel13.Controls.Add(Me.FlatComboBox15)
        Me.Panel13.Location = New System.Drawing.Point(460, 151)
        Me.Panel13.Name = "Panel13"
        Me.Panel13.Size = New System.Drawing.Size(117, 38)
        Me.Panel13.TabIndex = 38
        '
        'FlatComboBox15
        '
        Me.FlatComboBox15.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox15.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox15.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox15.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox15.Name = "FlatComboBox15"
        Me.FlatComboBox15.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox15.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox15.TabIndex = 42
        '
        'Panel14
        '
        Me.Panel14.BackColor = System.Drawing.SystemColors.Control
        Me.Panel14.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel14.Controls.Add(Me.FlatComboBox5)
        Me.Panel14.Location = New System.Drawing.Point(227, 151)
        Me.Panel14.Name = "Panel14"
        Me.Panel14.Size = New System.Drawing.Size(117, 38)
        Me.Panel14.TabIndex = 37
        '
        'FlatComboBox5
        '
        Me.FlatComboBox5.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox5.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox5.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox5.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox5.Name = "FlatComboBox5"
        Me.FlatComboBox5.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox5.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox5.TabIndex = 42
        '
        'Panel15
        '
        Me.Panel15.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel15.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel15.Controls.Add(Me.FlatComboBox16)
        Me.Panel15.Location = New System.Drawing.Point(460, 114)
        Me.Panel15.Name = "Panel15"
        Me.Panel15.Size = New System.Drawing.Size(117, 38)
        Me.Panel15.TabIndex = 36
        '
        'FlatComboBox16
        '
        Me.FlatComboBox16.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox16.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox16.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox16.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox16.Name = "FlatComboBox16"
        Me.FlatComboBox16.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox16.TabIndex = 42
        '
        'Panel16
        '
        Me.Panel16.BackColor = System.Drawing.SystemColors.Control
        Me.Panel16.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel16.Controls.Add(Me.FlatComboBox6)
        Me.Panel16.Location = New System.Drawing.Point(227, 114)
        Me.Panel16.Name = "Panel16"
        Me.Panel16.Size = New System.Drawing.Size(117, 38)
        Me.Panel16.TabIndex = 35
        '
        'FlatComboBox6
        '
        Me.FlatComboBox6.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox6.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox6.Font = New System.Drawing.Font("Microsoft Sans Serif", 12.0!, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, CType(0, Byte))
        Me.FlatComboBox6.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox6.Name = "FlatComboBox6"
        Me.FlatComboBox6.Size = New System.Drawing.Size(107, 28)
        Me.FlatComboBox6.TabIndex = 42
        '
        'Panel17
        '
        Me.Panel17.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel17.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel17.Controls.Add(Me.FlatComboBox11)
        Me.Panel17.Location = New System.Drawing.Point(460, 84)
        Me.Panel17.Name = "Panel17"
        Me.Panel17.Size = New System.Drawing.Size(117, 31)
        Me.Panel17.TabIndex = 34
        '
        'FlatComboBox11
        '
        Me.FlatComboBox11.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox11.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox11.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox11.Name = "FlatComboBox11"
        Me.FlatComboBox11.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox11.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox11.TabIndex = 42
        '
        'Panel18
        '
        Me.Panel18.BackColor = System.Drawing.SystemColors.Control
        Me.Panel18.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel18.Controls.Add(Me.FlatComboBox7)
        Me.Panel18.Location = New System.Drawing.Point(227, 84)
        Me.Panel18.Name = "Panel18"
        Me.Panel18.Size = New System.Drawing.Size(117, 31)
        Me.Panel18.TabIndex = 33
        '
        'FlatComboBox7
        '
        Me.FlatComboBox7.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox7.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox7.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox7.Name = "FlatComboBox7"
        Me.FlatComboBox7.RightToLeft = System.Windows.Forms.RightToLeft.Yes
        Me.FlatComboBox7.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox7.TabIndex = 42
        '
        'Panel19
        '
        Me.Panel19.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.Panel19.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel19.Controls.Add(Me.FlatComboBox10)
        Me.Panel19.Location = New System.Drawing.Point(460, 54)
        Me.Panel19.Name = "Panel19"
        Me.Panel19.Size = New System.Drawing.Size(117, 31)
        Me.Panel19.TabIndex = 32
        '
        'FlatComboBox10
        '
        Me.FlatComboBox10.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox10.FlatComboStyle = FlatCombo.FlatComboBox.styles.office2003
        Me.FlatComboBox10.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox10.Name = "FlatComboBox10"
        Me.FlatComboBox10.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox10.TabIndex = 42
        '
        'Panel20
        '
        Me.Panel20.BackColor = System.Drawing.SystemColors.Control
        Me.Panel20.BorderStyle = System.Windows.Forms.BorderStyle.FixedSingle
        Me.Panel20.Controls.Add(Me.FlatComboBox8)
        Me.Panel20.Location = New System.Drawing.Point(227, 54)
        Me.Panel20.Name = "Panel20"
        Me.Panel20.Size = New System.Drawing.Size(117, 31)
        Me.Panel20.TabIndex = 31
        '
        'FlatComboBox8
        '
        Me.FlatComboBox8.DropDownStyle = System.Windows.Forms.ComboBoxStyle.DropDownList
        Me.FlatComboBox8.FlatComboStyle = FlatCombo.FlatComboBox.styles.officeXP
        Me.FlatComboBox8.Location = New System.Drawing.Point(4, 4)
        Me.FlatComboBox8.Name = "FlatComboBox8"
        Me.FlatComboBox8.Size = New System.Drawing.Size(107, 21)
        Me.FlatComboBox8.TabIndex = 42
        '
        'demoForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.White
        Me.ClientSize = New System.Drawing.Size(586, 216)
        Me.Controls.Add(Me.Panel13)
        Me.Controls.Add(Me.Panel14)
        Me.Controls.Add(Me.Panel15)
        Me.Controls.Add(Me.Panel16)
        Me.Controls.Add(Me.Panel17)
        Me.Controls.Add(Me.Panel18)
        Me.Controls.Add(Me.Panel19)
        Me.Controls.Add(Me.Panel20)
        Me.Controls.Add(Me.Label9)
        Me.Controls.Add(Me.Label10)
        Me.Controls.Add(Me.Label8)
        Me.Controls.Add(Me.Label7)
        Me.Controls.Add(Me.Label5)
        Me.Controls.Add(Me.Panel7)
        Me.Controls.Add(Me.Panel8)
        Me.Controls.Add(Me.Label4)
        Me.Controls.Add(Me.Panel5)
        Me.Controls.Add(Me.Panel6)
        Me.Controls.Add(Me.Label1)
        Me.Controls.Add(Me.Panel2)
        Me.Controls.Add(Me.Panel4)
        Me.Controls.Add(Me.Label3)
        Me.Controls.Add(Me.Label2)
        Me.Controls.Add(Me.lblNormal)
        Me.Controls.Add(Me.Panel3)
        Me.Controls.Add(Me.Panel1)
        Me.Controls.Add(Me.chkEnabled)
        Me.Controls.Add(Me.lnkAbout)
        Me.Controls.Add(Me.lblAbout)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.Name = "demoForm"
        Me.Text = "Flat ComboBox Demo"
        Me.Panel1.ResumeLayout(False)
        Me.Panel3.ResumeLayout(False)
        Me.Panel2.ResumeLayout(False)
        Me.Panel4.ResumeLayout(False)
        Me.Panel5.ResumeLayout(False)
        Me.Panel6.ResumeLayout(False)
        Me.Panel7.ResumeLayout(False)
        Me.Panel8.ResumeLayout(False)
        Me.Panel13.ResumeLayout(False)
        Me.Panel14.ResumeLayout(False)
        Me.Panel15.ResumeLayout(False)
        Me.Panel16.ResumeLayout(False)
        Me.Panel17.ResumeLayout(False)
        Me.Panel18.ResumeLayout(False)
        Me.Panel19.ResumeLayout(False)
        Me.Panel20.ResumeLayout(False)
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub lnkAbout_LinkClicked(ByVal sender As System.Object, ByVal e As System.Windows.Forms.LinkLabelLinkClickedEventArgs) Handles lnkAbout.LinkClicked
        Dim aboutForm As New aboutForm
        aboutForm.ShowDialog()
    End Sub

    Private Sub chkEnabled_CheckedChanged(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles chkEnabled.CheckedChanged
        Dim control, child As Control
        For Each control In Controls
            For Each child In control.Controls
                If TypeOf child Is System.Windows.Forms.ComboBox Then
                    If child.Enabled Then
                        child.Enabled = False
                    Else
                        child.Enabled = True
                    End If
                End If
            Next
        Next
    End Sub

    Private Sub demoForm_Load(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles MyBase.Load
        Dim control, child As Control
        Dim combo As ComboBox
        Dim i As Integer
        For Each control In Controls
            For Each child In control.Controls
                If TypeOf child Is System.Windows.Forms.ComboBox Then
                    combo = child
                    For i = 1 To 10
                        combo.Items.Add("Item " & i.ToString)
                    Next
                    combo.Items.Add("This_is_an_extra_long_text")
                    combo.SelectedIndex = 0
                End If
            Next
        Next
    End Sub
End Class
