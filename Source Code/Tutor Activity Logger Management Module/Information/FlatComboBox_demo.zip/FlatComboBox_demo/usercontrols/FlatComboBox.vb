'***************************************************************************'
'*                                                                         *'
'*  Description:    How to create a flat combobox                          *'
'*  Author:         Devinck Wouter                                         *'
'*  Date:           Summer 2005                                            *'
'*  Published:      http://www.thecodeproject.com/vb/net/FlatComboBox.asp  *'                                                                      *'
'*  Bugfix:         August 2005                                            *'
'*  First revision: Oktober - November 2005                                *'
'*                                                                         *'
'***************************************************************************'

Imports System.Drawing.Drawing2D

Public Class FlatComboBox
    Inherits System.Windows.Forms.ComboBox

#Region " Globals "
    'Enum with all the possible styles
    Enum styles
        officeXP
        office2003
    End Enum

    'Enum with all the possible states
    Enum states
        normal
        focused
        dropeddown
        disabled
    End Enum

    'Variable to save the current style
    Dim style As styles = styles.officeXP
    'Variable to save the current state
    Dim state As states = states.normal
    'All the pen and brushes needed 
    Dim BorderPen As Pen
    Dim ArrowBrush, ButtonBrush, TextBrush As Brush
    'The rectangle, surounding the hole control
    Dim MainRect As Rectangle
    'The rectangle, surounding the hole button
    Dim ButtonSurRect As Rectangle
    'The rectangle for the button
    Dim ButtonRect As Rectangle
    'The three points of the arrow
    Dim pntArrow(2) As PointF
    'The middle of the button, used to center the arrow
    Dim VerticalMiddle As Integer
    'The path for the arrow
    Dim ArrowPath As GraphicsPath = New GraphicsPath
    'The location for drawing the text (in case dropdownstyle=dropdownlist)
    Dim TextLocation As PointF
    'The graphics
    Dim g As Graphics
#End Region

#Region " Listener "

    Protected Overrides Sub WndProc(ByRef m As System.Windows.Forms.Message)
        MyBase.WndProc(m)
        Select Case m.Msg

            Case &HF
                'WM_PAINT

                '"simple" is not currently supported
                If Me.DropDownStyle = ComboBoxStyle.Simple Then Exit Sub

                '==========START DRAWING===========
                g = Me.CreateGraphics
                'clear everything
                If Me.Enabled Then
                    g.Clear(Color.White)
                Else
                    g.Clear(Color.FromName("control"))
                End If
                'call the drawing functions
                DrawButton(g)
                DrawArrow(g)
                DrawBorder(g)
                DrawText(g)
                '===========STOP DRAWING============

            Case 7, 8, &H7, &H8, &H200, &H2A3
                'CMB_DROPDOWN, CMB_CLOSEUP, WM_SETFOCUS, 
                'WM_KILLFOCUS, WM_MOUSEMOVE,  
                'WM_MOUSELEAVE (if you move the mouse fast over
                'the combobox, mouseleave doesn't always react)

                UpdateState()

        End Select

    End Sub

    'Enable/Disable
    Private Sub FlatComboBox_EnabledChanged(ByVal sender As Object, ByVal e As System.EventArgs) Handles MyBase.EnabledChanged
        UpdateState()
    End Sub

    'Cause WM_MOUSELEAVE doesn't always react, this timer refreshes the control every 20 miliseconds
    Private WithEvents Timer As Timer = New Timer
    Public Sub New()
        Timer.Interval = 20
        Timer.Enabled = True
    End Sub
    Private Sub Timer_Tick(ByVal sender As Object, ByVal e As System.EventArgs) Handles Timer.Tick
        UpdateState()
    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal e As Boolean)
        Me.Timer.Enabled = False
        MyBase.Dispose(e)
    End Sub

    Function UpdateState()
        'save the current state
        Dim temp As states = state
        '
        If Me.Enabled Then
            If Me.DroppedDown Then
                Me.state = states.dropeddown
            Else
                If ClientRectangle.Contains(PointToClient(Me.MousePosition)) Then
                    Me.state = states.focused
                ElseIf Me.Focused Then
                    Me.state = states.focused
                Else
                    Me.state = states.normal
                End If
            End If
        Else
            Me.state = states.disabled
        End If
        'only redraw if the state has changed
        If state <> temp Then
            Me.Invalidate()
        End If
    End Function
#End Region

#Region " Public property's "
    'Property to let the user change the style
    Public Property FlatComboStyle() As styles
        Get
            Return style
        End Get
        Set(ByVal Value As styles)
            style = Value
        End Set
    End Property
#End Region

#Region " Drawing functions "

    Function DrawButton(ByVal g As Graphics)
        If Me.RightToLeft = RightToLeft.No Then
            ButtonRect = New Rectangle(Me.Width - 18, 1, 17, Me.Height - 2)
        Else
            ButtonRect = New Rectangle(1, 1, 17, Me.Height - 2)
        End If
        Select Case state
            Case states.normal
                Select Case style
                    Case styles.officeXP
                        ButtonBrush = New SolidBrush(Color.FromName("control"))
                    Case styles.office2003
                        ButtonBrush = New LinearGradientBrush(ButtonRect, Color.FromArgb(214, 232, 253), Color.FromArgb(156, 189, 235), LinearGradientMode.Vertical)
                End Select
            Case states.focused
                Select Case style
                    Case styles.officeXP
                        ButtonBrush = New SolidBrush(Color.FromArgb(193, 210, 238))
                    Case styles.office2003
                        ButtonBrush = New LinearGradientBrush(ButtonRect, Color.FromArgb(255, 242, 200), Color.FromArgb(255, 210, 148), LinearGradientMode.Vertical)
                End Select
            Case states.dropeddown
                Select Case style
                    Case styles.officeXP
                        ButtonBrush = New SolidBrush(Color.FromArgb(152, 181, 226))
                    Case styles.office2003
                        ButtonBrush = New LinearGradientBrush(ButtonRect, Color.FromArgb(254, 149, 82), Color.FromArgb(255, 207, 139), LinearGradientMode.Vertical)
                End Select
            Case states.disabled
                ButtonBrush = New SolidBrush(Color.FromName("control"))
        End Select
        g.FillRectangle(ButtonBrush, ButtonRect)
    End Function

    Function DrawArrow(ByVal g As Graphics)
        VerticalMiddle = CInt(Me.Height / 2)
        If Me.RightToLeft = RightToLeft.No Then
            pntArrow(0) = New PointF(Me.Width - 11, VerticalMiddle - 1)
            pntArrow(1) = New PointF(Me.Width - 9, VerticalMiddle + 2)
            pntArrow(2) = New PointF(Me.Width - 6, VerticalMiddle - 1)
        Else
            pntArrow(0) = New PointF(7, VerticalMiddle - 1)
            pntArrow(1) = New PointF(9, VerticalMiddle + 2)
            pntArrow(2) = New PointF(12, VerticalMiddle - 1)
        End If
        Select Case Me.state
            Case states.normal, states.focused
                ArrowBrush = New SolidBrush(Color.Black)
            Case states.dropeddown
                Select Case Me.style
                    Case styles.officeXP
                        ArrowBrush = New SolidBrush(Color.FromArgb(73, 73, 73))
                    Case styles.office2003
                        ArrowBrush = New SolidBrush(Color.Black)
                End Select
            Case states.disabled
                ArrowBrush = New SolidBrush(Color.DarkGray)
        End Select
        g.FillPolygon(ArrowBrush, pntArrow)
    End Function

    Function DrawBorder(ByVal g As Graphics)
        MainRect = New Rectangle(0, 0, Me.Width - 1, Me.Height - 1)
        If Me.RightToLeft Then
            ButtonSurRect = New Rectangle(0, 0, ButtonRect.Width + 1, ButtonRect.Height + 1)
        Else
            ButtonSurRect = New Rectangle(ButtonRect.X - 1, ButtonRect.Y - 1, ButtonRect.Width + 2, ButtonRect.Height + 2)
        End If
        Select Case state
            Case states.focused, states.dropeddown
                Select Case Me.style
                    Case styles.officeXP
                        BorderPen = New Pen(Color.FromArgb(49, 106, 197))
                    Case styles.office2003
                        BorderPen = New Pen(Color.FromArgb(0, 0, 128))
                End Select
            Case states.disabled
                BorderPen = New Pen(Color.DarkGray)
            Case Else
                Exit Function
        End Select
        If Not state = states.disabled Then g.DrawRectangle(BorderPen, ButtonSurRect)
        g.DrawRectangle(BorderPen, MainRect)
    End Function

    Function DrawText(ByVal g As Graphics)
        If Me.DropDownStyle <> ComboBoxStyle.DropDownList Then Exit Function
        Dim text As String
        Select Case state
            Case states.normal, states.focused, states.dropeddown
                TextBrush = New SolidBrush(Me.ForeColor)
            Case states.disabled
                TextBrush = New SolidBrush(Color.DarkGray)
        End Select
        If g.MeasureString(Me.Text, Me.Font).Width > Me.Width - 30 Then
            Dim i As Integer = -1
            Do
                i += 1
                If g.MeasureString(text, Me.Font).Width > Me.Width - 30 Then Exit Do
                text &= Me.Text.Substring(i, 1)
            Loop
        Else
            text = Me.Text
        End If
        If Me.RightToLeft = RightToLeft.No Then
            TextLocation = New PointF(1, 4)
        Else
            Dim temp As Single = Me.Width - (g.MeasureString(text, Me.Font).Width)
            TextLocation = New PointF(temp, 4)
        End If
        g.DrawString(text, Me.Font, TextBrush, TextLocation)
    End Function
#End Region

End Class

