Imports System.Reflection
Public Class aboutForm
    Inherits System.Windows.Forms.Form

#Region " Windows Form Designer generated code "

    Public Sub New()
        MyBase.New()

        'This call is required by the Windows Form Designer.
        InitializeComponent()

        'Add any initialization after the InitializeComponent() call

    End Sub

    'Form overrides dispose to clean up the component list.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
        If disposing Then
            If Not (components Is Nothing) Then
                components.Dispose()
            End If
        End If
        MyBase.Dispose(disposing)
    End Sub

    'Required by the Windows Form Designer
    Private components As System.ComponentModel.IContainer

    'NOTE: The following procedure is required by the Windows Form Designer
    'It can be modified using the Windows Form Designer.  
    'Do not modify it using the code editor.
    Friend WithEvents picFlatCombo As System.Windows.Forms.PictureBox
    Friend WithEvents btnClose As System.Windows.Forms.Button
    Friend WithEvents lblCreator As System.Windows.Forms.Label
    Friend WithEvents lblVersion As System.Windows.Forms.Label
    Friend WithEvents listAssemblies As System.Windows.Forms.ListBox
    Friend WithEvents lblAssemblies As System.Windows.Forms.Label
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
        Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(aboutForm))
        Me.picFlatCombo = New System.Windows.Forms.PictureBox
        Me.btnClose = New System.Windows.Forms.Button
        Me.lblCreator = New System.Windows.Forms.Label
        Me.lblVersion = New System.Windows.Forms.Label
        Me.listAssemblies = New System.Windows.Forms.ListBox
        Me.lblAssemblies = New System.Windows.Forms.Label
        Me.SuspendLayout()
        '
        'picFlatCombo
        '
        Me.picFlatCombo.Image = CType(resources.GetObject("picFlatCombo.Image"), System.Drawing.Image)
        Me.picFlatCombo.Location = New System.Drawing.Point(0, 8)
        Me.picFlatCombo.Name = "picFlatCombo"
        Me.picFlatCombo.Size = New System.Drawing.Size(300, 50)
        Me.picFlatCombo.TabIndex = 0
        Me.picFlatCombo.TabStop = False
        '
        'btnClose
        '
        Me.btnClose.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.btnClose.Location = New System.Drawing.Point(218, 216)
        Me.btnClose.Name = "btnClose"
        Me.btnClose.TabIndex = 1
        Me.btnClose.Text = "Close"
        '
        'lblCreator
        '
        Me.lblCreator.Location = New System.Drawing.Point(16, 72)
        Me.lblCreator.Name = "lblCreator"
        Me.lblCreator.Size = New System.Drawing.Size(272, 20)
        Me.lblCreator.TabIndex = 2
        Me.lblCreator.Text = "Developed by Devinck Wouter"
        Me.lblCreator.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'lblVersion
        '
        Me.lblVersion.Location = New System.Drawing.Point(16, 96)
        Me.lblVersion.Name = "lblVersion"
        Me.lblVersion.Size = New System.Drawing.Size(272, 20)
        Me.lblVersion.TabIndex = 3
        Me.lblVersion.Text = "<version>"
        Me.lblVersion.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'listAssemblies
        '
        Me.listAssemblies.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.listAssemblies.Location = New System.Drawing.Point(16, 144)
        Me.listAssemblies.Name = "listAssemblies"
        Me.listAssemblies.Size = New System.Drawing.Size(272, 56)
        Me.listAssemblies.TabIndex = 8
        '
        'lblAssemblies
        '
        Me.lblAssemblies.FlatStyle = System.Windows.Forms.FlatStyle.System
        Me.lblAssemblies.Location = New System.Drawing.Point(16, 128)
        Me.lblAssemblies.Name = "lblAssemblies"
        Me.lblAssemblies.Size = New System.Drawing.Size(100, 16)
        Me.lblAssemblies.TabIndex = 7
        Me.lblAssemblies.Text = "Assemblies:"
        Me.lblAssemblies.TextAlign = System.Drawing.ContentAlignment.MiddleLeft
        '
        'aboutForm
        '
        Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
        Me.BackColor = System.Drawing.Color.FromArgb(CType(193, Byte), CType(210, Byte), CType(238, Byte))
        Me.ClientSize = New System.Drawing.Size(300, 248)
        Me.Controls.Add(Me.listAssemblies)
        Me.Controls.Add(Me.lblAssemblies)
        Me.Controls.Add(Me.lblVersion)
        Me.Controls.Add(Me.lblCreator)
        Me.Controls.Add(Me.btnClose)
        Me.Controls.Add(Me.picFlatCombo)
        Me.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle
        Me.Icon = CType(resources.GetObject("$this.Icon"), System.Drawing.Icon)
        Me.MaximizeBox = False
        Me.MinimizeBox = False
        Me.Name = "aboutForm"
        Me.StartPosition = System.Windows.Forms.FormStartPosition.CenterParent
        Me.Text = "About"
        Me.ResumeLayout(False)

    End Sub

#End Region

    Private Sub btnClose_Click(ByVal sender As System.Object, ByVal e As System.EventArgs) Handles btnClose.Click
        Me.Close()
    End Sub

    Protected Overrides Sub OnLoad(ByVal e As System.EventArgs)
        MyBase.OnLoad(e)

        ' update the version
        Dim ver As String() = Application.ProductVersion.Split("."c)
        lblVersion.Text = String.Format("Version {0}.{1}.{2}", _
         ver(0), ver(1), ver(2))

        ' get list of assemblies used by this app
        Dim other As AssemblyName() = Reflection.Assembly.GetExecutingAssembly().GetReferencedAssemblies()
        For Each a As AssemblyName In other
            listAssemblies.Items.Add(String.Format("{0} ({1})", _
             a.Name, a.Version.ToString()))
        Next
    End Sub
End Class
