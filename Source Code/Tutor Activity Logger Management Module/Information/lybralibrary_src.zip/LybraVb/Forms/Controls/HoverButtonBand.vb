Namespace Lybra.Forms.Controls

  <Designer(GetType(System.Windows.Forms.Design.ParentControlDesigner), GetType(IDesigner)), _
            DesignTimeVisibleAttribute(True), DefaultProperty("Text"), DefaultEvent("Click")> _
  Public Class HoverButtonBand
    Inherits System.Windows.Forms.Panel

#Region "Private fields"

    Private mTextAlign As ContentAlignment = ContentAlignment.MiddleCenter
    Private mTextQuality As LybraEnums.TextRendering = LybraEnums.TextRendering.SystemDefault

    Public Enum HowReorder As Integer
      Horizontal = 1
      Vertical = 2
    End Enum
    Public Enum HowAlign As Integer
      Center = 1
      LeftOrTop = 2
    End Enum

    Private mBorder As Boolean = False
    Private mBorderNormalColor As Color = Color.FromArgb(179, 176, 208)
    Private mBackColor1 As Color = Color.FromArgb(221, 236, 254)
    Private mBackColor2 As Color = Color.FromArgb(129, 169, 226)
    Private mGradientMode As Drawing2D.LinearGradientMode = Drawing2D.LinearGradientMode.Vertical
    Private mAutoArrange As Boolean = False
    Private mAutoArrangeDirection As HowReorder = HowReorder.Horizontal
    Private mAutoArrangeAlignment As HowAlign = HowAlign.LeftOrTop
    Private mAutoArrangeButtonSpace As Integer = 5
    Private mAutoArrangMargin As Integer = 5

#End Region

#Region "Codice generato da Progettazione Windows Form"

    Public Sub New()
      MyBase.New()

      ' This call is required by the Component Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

      ' This draws the control whenever it is resized
      setstyle(ControlStyles.ResizeRedraw, True)

      ' This supports mouse movement such as the mouse wheel
      setstyle(ControlStyles.UserMouse, True)

      ' This allows the control to be transparent
      setstyle(ControlStyles.SupportsTransparentBackColor, True)

      ' This helps with drawing the control so that it doesn't flicker
      Me.SetStyle(ControlStyles.DoubleBuffer _
        Or ControlStyles.UserPaint _
        Or ControlStyles.AllPaintingInWmPaint, _
        True)

      ' This control is a container
      setstyle(ControlStyles.ContainerControl, True)

      ' This updates the styles
      Me.UpdateStyles()

    End Sub

    'UserControl esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
        If Not (components Is Nothing) Then
          components.Dispose()
        End If
      End If
      MyBase.Dispose(disposing)
    End Sub

    'Richiesto da Progettazione Windows Form
    Private components As System.ComponentModel.IContainer

    'NOTA: la procedura che segue � richiesta da Progettazione Windows Form.
    'Pu� essere modificata in Progettazione Windows Form.  
    'Non modificarla nell'editor del codice.
    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      components = New System.ComponentModel.Container
    End Sub

#End Region

#Region "Public Properties"

#Region "Property TextAlign"
    <DefaultValue(GetType(ContentAlignment), "MiddleCenter")> _
  Public Property TextAlign() As ContentAlignment
      Get
        Return mTextAlign
      End Get
      Set(ByVal Value As ContentAlignment)
        mTextAlign = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property TextQuality"
    <DefaultValue(GetType(LybraEnums.TextRendering), "SystemDefault")> _
    Public Property TextQuality() As LybraEnums.TextRendering
      Get
        Return mTextQuality
      End Get
      Set(ByVal Value As LybraEnums.TextRendering)
        mTextQuality = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property Border"
    <DefaultValue(GetType(Boolean), "False")> _
    Public Property Border() As Boolean
      Get
        Return mBorder
      End Get
      Set(ByVal Value As Boolean)
        mBorder = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property BorderNormalColor"
    <DefaultValue(GetType(Color), "179, 176, 208")> _
    Public Property BorderNormalColor() As Color
      Get
        Return mBorderNormalColor
      End Get
      Set(ByVal Value As Color)
        If Value.Equals(Color.Empty) Then Value = Color.AliceBlue
        mBorderNormalColor = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property BackColor1"
    <DefaultValue(GetType(Color), "221, 236, 254")> _
    Public Property BackColor1() As Color
      Get
        Return mBackColor1
      End Get
      Set(ByVal value As Color)
        If value.Equals(Color.Empty) Then value = Color.FromArgb(221, 236, 254)
        mBackColor1 = value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property BackColor2"
    <DefaultValue(GetType(Color), "129, 169, 226")> _
    Public Property BackColor2() As Color
      Get
        Return mBackColor2
      End Get
      Set(ByVal value As Color)
        If value.Equals(Color.Empty) Then value = Color.FromArgb(129, 169, 226)
        mBackColor2 = value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property GradientMode"
    <DefaultValue(GetType(Drawing2D.LinearGradientMode), "Vertical")> _
    Public Property GradientMode() As Drawing2D.LinearGradientMode
      Get
        Return mGradientMode
      End Get
      Set(ByVal value As Drawing2D.LinearGradientMode)
        mGradientMode = value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property AutoArrange"
    <DefaultValue(GetType(Boolean), "False")> _
    Public Property AutoArrange() As Boolean
      Get
        Return mAutoArrange
      End Get
      Set(ByVal value As Boolean)
        mAutoArrange = value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property AutoArrangeDirection"
    <DefaultValue(GetType(HowReorder), "Horizontal")> _
    Public Property AutoArrangeDirection() As HowReorder
      Get
        Return mAutoArrangeDirection
      End Get
      Set(ByVal Value As HowReorder)
        mAutoArrangeDirection = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property AutoArrangeAlignment"
    <DefaultValue(GetType(HowAlign), "LeftOrTop")> _
    Public Property AutoArrangeAlignment() As HowAlign
      Get
        Return mAutoArrangeAlignment
      End Get
      Set(ByVal Value As HowAlign)
        mAutoArrangeAlignment = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property AutoArrangeButtonSpace"
    <DefaultValue(GetType(Integer), "5")> _
    Public Property AutoArrangeButtonSpace() As Integer
      Get
        Return mAutoArrangeButtonSpace
      End Get
      Set(ByVal Value As Integer)
        mAutoArrangeButtonSpace = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Property AutoArrangMargin"
    <DefaultValue(GetType(Integer), "5")> _
    Public Property AutoArrangMargin() As Integer
      Get
        Return mAutoArrangMargin
      End Get
      Set(ByVal Value As Integer)
        mAutoArrangMargin = Value
        Invalidate()
      End Set
    End Property
#End Region

#End Region

#Region "Public Overrided Properties"
    <Browsable(True), DesignerSerializationVisibility(DesignerSerializationVisibility.Visible)> _
  Public Overrides Property Text() As String
      Get
        Return MyBase.Text
      End Get
      Set(ByVal Value As String)
        MyBase.Text = Value
        Invalidate()
      End Set
    End Property
#End Region

#Region "Protected Overrided Methods"

#Region "-------> OnPaint Overrided Method"
    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)

      'Draw background
      GS.PaintGradientRectangle(e.Graphics, 0, 0, Me.Width, Me.Height, _
                                mBackColor1, mBackColor2, mGradientMode)

      ' Draw the border
      If mBorder Then GS.PaintBorder(e.Graphics, 0, 0, Me.Width, Me.Height, _
                                     mBorderNormalColor)

      'Arrange buttons
      If mAutoArrange Then AlignButtons.ButtonsReorder(Me.Controls, _
                                                       mAutoArrangeDirection, _
                                                       mAutoArrangeAlignment, _
                                                       mAutoArrangMargin, _
                                                       mAutoArrangeButtonSpace)

      'Draw text
      GS.WriteText(e.Graphics, Me.Text, Me.Font, _
                   Me.TextAlign, mTextQuality, _
                   Me.ForeColor, _
                   0, 0, Me.Width, Me.Height)

    End Sub
#End Region

    Protected Overrides Sub OnControlAdded(ByVal e As System.Windows.Forms.ControlEventArgs)
      MyBase.OnControlAdded(e)
      '  If (e.Control.GetType Is GetType(HoverGradientButton)) Then
      '  Else        '
      '    'No works because allows drag-and-drop
      '    '
      '    'Debug.WriteLine(e.Control.GetType.ToString & " > " & GetType(HoverGradientButton).ToString & " NON AMMESSO 4")
      '    'If added control if not HoverGradientButton, then remove the control
      '    'Me.Controls.Remove(e.Control)
      '    'Throw an error
      '    Throw New InvalidCastException("Only HoverGradientButton can be added to the HoverButtonBand")
      '    e.Control.Parent = Me.Parent

      '  End If
    End Sub
#End Region

#Region "Class AlignButtons"

    Friend Class AlignButtons

      Public Sub New()
      End Sub

      Public Shared Sub ButtonsReorder(ByRef aObjects As _
                                             System.Windows.Forms.Control.ControlCollection, _
                                       ByVal rType As HowReorder, _
                                       ByVal rAlign As HowAlign, _
                                       Optional ByVal iMargin As Integer = 0, _
                                       Optional ByVal iSpacer As Integer = 0)

        If aObjects.Equals(Nothing) Then Exit Sub
        If aObjects.Count = 0 Then Exit Sub

        Dim CountOfControls As Integer = aObjects.Count

        Dim cContainer As Control = CType(aObjects.Item(0), Control).Parent
        Dim WidthOfContainer As Integer = cContainer.Width
        Dim HeightOfContainer As Integer = cContainer.Height
        Dim WidthOfControlli As Integer = 0
        Dim HeightOfControlli As Integer = 0

        Dim o As Control
        For Each o In aObjects
          WidthOfControlli += o.Width
          HeightOfControlli += o.Height
        Next

        Dim VariablePosition As Integer = 0
        Dim FixedPosition As Integer = 0

        Select Case rType
          Case HowReorder.Horizontal
            VariablePosition = iMargin
            FixedPosition = Convert.ToInt32((HeightOfContainer - o.Height) / 2)
            For Each o In aObjects
              o.Left = VariablePosition
              o.Top = FixedPosition
              If rAlign = HowAlign.Center Then iSpacer = Convert.ToInt32((WidthOfContainer - _
                                          WidthOfControlli - iMargin) / (CountOfControls + 1))
              VariablePosition = VariablePosition + iSpacer + o.Width
            Next
          Case HowReorder.Vertical
            VariablePosition = iMargin
            FixedPosition = Convert.ToInt32((WidthOfContainer - o.Height) / 2)
            For Each o In aObjects
              o.Top = VariablePosition
              o.Left = FixedPosition
              If rAlign = HowAlign.Center Then iSpacer = Convert.ToInt32((HeightOfContainer - _
                                          HeightOfControlli - iMargin) / (CountOfControls + 1))
              VariablePosition = VariablePosition + iSpacer + o.Width
            Next
        End Select

      End Sub

    End Class

#End Region

  End Class

End Namespace

