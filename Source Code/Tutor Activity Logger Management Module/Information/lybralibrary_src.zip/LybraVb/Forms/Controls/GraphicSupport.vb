Namespace Lybra.Forms.Controls

#Region "Class GraphicSupport"
  Friend Class GS 'Graphic Support

#Region "Shared Method XRectangleF"
    Public Shared Function XRectangleF(ByVal x As Single, ByVal y As Single, ByVal width As Single, ByVal height As Single) As RectangleF
      If width < 1 Then width = 1
      If height < 1 Then height = 1
      Return New RectangleF(x, y, width, height)
    End Function
#End Region

#Region "Shared Method XRectangle"
    Public Shared Function XRectangle(ByVal x As Integer, ByVal y As Integer, ByVal width As Integer, ByVal height As Integer) As Rectangle
      If width < 1 Then width = 1
      If height < 1 Then height = 1
      Return New Rectangle(x, y, width, height)
    End Function
#End Region

#Region " Conversion: Point2PointF, PointF2Point, Size2SizeF, SizeF2Size, Rect2RectF, RectF2Rect"
    Public Shared Function Point2PointF(ByVal aPoint As Point) As PointF
      Return New PointF(Convert.ToSingle(aPoint.X), Convert.ToSingle(aPoint.Y))
    End Function
    Public Shared Function PointF2Point(ByVal aPointF As PointF) As Point
      Return New Point(Convert.ToInt32(aPointF.X), Convert.ToInt32(aPointF.Y))
    End Function
    Public Shared Function Size2SizeF(ByVal aSize As Size) As SizeF
      Return New SizeF(Convert.ToSingle(aSize.Width), Convert.ToSingle(aSize.Height))
    End Function
    Public Shared Function SizeF2Size(ByVal aSizeF As SizeF) As Size
      Return New Size(Convert.ToInt32(aSizeF.Width), Convert.ToInt32(aSizeF.Height))
    End Function
    Public Shared Function Rect2RectF(ByVal aRectangle As Rectangle) As RectangleF
      Return New RectangleF(Convert.ToSingle(aRectangle.X), _
                            Convert.ToSingle(aRectangle.Y), _
                            Convert.ToSingle(aRectangle.Width), _
                            Convert.ToSingle(aRectangle.Height))
    End Function
    Public Shared Function RectF2Rect(ByVal aRectangleF As RectangleF) As Rectangle
      Return New Rectangle(Convert.ToInt32(aRectangleF.X), _
                            Convert.ToInt32(aRectangleF.Y), _
                            Convert.ToInt32(aRectangleF.Width), _
                            Convert.ToInt32(aRectangleF.Height))
    End Function
#End Region

#Region "Shared Method PaintGradientRectangle"
    Public Shared Function PaintGradientRectangle(ByVal g As Drawing.Graphics, _
                           ByVal aPointX As Integer, _
                           ByVal aPointY As Integer, _
                           ByVal aWidth As Integer, _
                           ByVal aHeight As Integer, _
                           ByVal aColor1 As Color, _
                           ByVal aColor2 As Color, _
                           ByVal aGradientMode As Drawing2D.LinearGradientMode) As RectangleF

      Dim RectanglePaint As RectangleF = GS.XRectangleF(aPointX, aPointY, aWidth, aHeight)
      Dim gradBrush As New System.Drawing.Drawing2D.LinearGradientBrush(RectanglePaint, aColor1, aColor2, aGradientMode)
      g.FillRectangle(gradBrush, RectanglePaint)
      Return RectanglePaint

    End Function
#End Region

#Region "Shared Method PaintBorder"
    Public Shared Sub PaintBorder(ByVal g As Drawing.Graphics, _
                                  ByVal aPointX As Integer, _
                                  ByVal aPointY As Integer, _
                                  ByVal aWidth As Integer, _
                                  ByVal aHeight As Integer, _
                                  ByVal aColor As Color)

      Dim BorderPen As New Pen(New SolidBrush(aColor), 1)
      g.DrawRectangle(BorderPen, GS.XRectangle(aPointX, aPointY, aWidth - 1, aHeight - 1))
    End Sub
#End Region

#Region "Shared Method PaintWatermark"
    Friend Shared Sub PaintWatermark(ByVal g As Graphics, _
                                     ByVal aImage As Image, _
                                     ByVal aWatermarkArea As Rectangle, _
                                     ByVal aWatermarkSize As Size, _
                                     ByVal aWatermarkPosition As ContentAlignment)

      If aImage Is Nothing Then Return
      If aWatermarkSize.IsEmpty Then aWatermarkSize = aImage.Size

      Dim p As New Point
      p = GS.GetPointAligned(aWatermarkSize, aWatermarkArea.Location, aWatermarkArea.Size, aWatermarkPosition)

      Dim mWatermarkRectangle As Rectangle = GS.XRectangle(p.X, p.Y, _
                                                           aWatermarkSize.Width, aWatermarkSize.Height)

      Dim imgAttributes As ImageAttributes = GetMatrix()
      g.DrawImage(aImage, mWatermarkRectangle, _
                  0, 0, aImage.Width, aImage.Height, _
                  GraphicsUnit.Pixel, imgAttributes)

      imgAttributes.Dispose()

    End Sub
#End Region

#Region " Shared Method GetMatrix "
    Private Shared Function GetMatrix() As ImageAttributes
      Dim mColorMatrix As ColorMatrix = New ColorMatrix
      mColorMatrix.Matrix33 = 0.12F
      mColorMatrix.Matrix00 = 1 / 3.0F
      mColorMatrix.Matrix01 = 1 / 3.0F
      mColorMatrix.Matrix02 = 1 / 3.0F
      mColorMatrix.Matrix10 = 1 / 3.0F
      mColorMatrix.Matrix11 = 1 / 3.0F
      mColorMatrix.Matrix12 = 1 / 3.0F
      mColorMatrix.Matrix20 = 1 / 3.0F
      mColorMatrix.Matrix21 = 1 / 3.0F
      mColorMatrix.Matrix22 = 1 / 3.0F
      Dim imgAttributes As New ImageAttributes
      imgAttributes.SetColorMatrix(mColorMatrix, ColorMatrixFlag.Default, ColorAdjustType.Bitmap)
      Return imgAttributes
    End Function
#End Region

#Region "Shared Method ImageContentAlign"
    Public Overloads Shared Function GetPointAligned(ByVal aObjectSize As Size, _
                                                     ByVal aPositionInsideContainer As Point, _
                                                     ByVal aContainerSize As Size, _
                                                     ByVal aMarginLeft As Integer, _
                                                     ByVal aMarginRight As Integer, _
                                                     ByVal aMarginTop As Integer, _
                                                     ByVal aMarginBottom As Integer, _
                                                     ByVal aAlign As ContentAlignment) As Point

      If aObjectSize.Height = 0 AndAlso aObjectSize.Width = 0 Then Return New Point(0, 0)

      Dim X As Integer = 0
      Dim Y As Integer = 0

      Select Case aAlign
        Case ContentAlignment.BottomCenter
          X = Convert.ToInt32((aContainerSize.Width / 2) - (aObjectSize.Width / 2))
          Y = aContainerSize.Height - aObjectSize.Height - aMarginBottom
        Case ContentAlignment.BottomLeft
          X = 0 + aMarginLeft
          Y = aContainerSize.Height - aObjectSize.Height - aMarginBottom
        Case ContentAlignment.BottomRight
          X = aContainerSize.Width - aObjectSize.Width - aMarginRight
          Y = aContainerSize.Height - aObjectSize.Height - aMarginBottom
        Case ContentAlignment.MiddleCenter
          X = Convert.ToInt32((aContainerSize.Width / 2) - (aObjectSize.Width / 2))
          Y = Convert.ToInt32((aContainerSize.Height / 2) - (aObjectSize.Height / 2))
        Case ContentAlignment.MiddleLeft
          X = 0 + aMarginLeft
          Y = Convert.ToInt32((aContainerSize.Height / 2) - (aObjectSize.Height / 2))
        Case ContentAlignment.MiddleRight
          X = aContainerSize.Width - aObjectSize.Width - aMarginRight
          Y = Convert.ToInt32((aContainerSize.Height / 2) - (aObjectSize.Height / 2))
        Case ContentAlignment.TopCenter
          X = Convert.ToInt32((aContainerSize.Width / 2) - (aObjectSize.Width / 2))
          Y = 0 + aMarginTop
        Case ContentAlignment.TopLeft
          X = 0 + aMarginLeft
          Y = 0 + aMarginTop
        Case ContentAlignment.TopRight
          X = aContainerSize.Width - aObjectSize.Width - aMarginRight
          Y = 0 + aMarginTop
      End Select

      Return New Point(X + aPositionInsideContainer.X, Y + aPositionInsideContainer.Y)

    End Function

    Public Overloads Shared Function GetPointAligned(ByVal sObjectSize As Size, _
                                                     ByVal aPositionInsideContainer As Point, _
                                                     ByVal aContainerSize As Size, _
                                                     ByVal aAlign As ContentAlignment) As Point
      Return GetPointAligned(sObjectSize, aPositionInsideContainer, aContainerSize, 0, 0, 0, 0, aAlign)
    End Function

#End Region

#Region "Shared Method WriteText"
    Friend Shared Sub WriteText(ByVal g As Drawing.Graphics, _
                                     ByVal aText As String, _
                                     ByVal aFont As Font, _
                                     ByVal aContentAlignment As System.Drawing.ContentAlignment, _
                                     ByVal aTextQuality As LybraEnums.TextRendering, _
                                     ByVal aSolidBrushColor As Color, _
                                     ByVal aPointX As Integer, _
                                     ByVal aPointY As Integer, _
                                     ByVal aWidth As Integer, _
                                     ByVal aHeight As Integer)

      Dim StrFormat As New System.Drawing.StringFormat

      Select Case aContentAlignment
        Case ContentAlignment.BottomCenter
          StrFormat.LineAlignment = StringAlignment.Far
          StrFormat.Alignment = StringAlignment.Center
        Case ContentAlignment.BottomLeft
          StrFormat.LineAlignment = StringAlignment.Far
          StrFormat.Alignment = StringAlignment.Near
        Case ContentAlignment.BottomRight
          StrFormat.LineAlignment = StringAlignment.Far
          StrFormat.Alignment = StringAlignment.Far

        Case ContentAlignment.MiddleCenter
          StrFormat.LineAlignment = StringAlignment.Center
          StrFormat.Alignment = StringAlignment.Center
        Case ContentAlignment.MiddleLeft
          StrFormat.LineAlignment = StringAlignment.Center
          StrFormat.Alignment = StringAlignment.Near
        Case ContentAlignment.MiddleRight
          StrFormat.LineAlignment = StringAlignment.Center
          StrFormat.Alignment = StringAlignment.Far

        Case ContentAlignment.TopCenter
          StrFormat.LineAlignment = StringAlignment.Near
          StrFormat.Alignment = StringAlignment.Center
        Case ContentAlignment.TopLeft
          StrFormat.LineAlignment = StringAlignment.Near
          StrFormat.Alignment = StringAlignment.Near
        Case ContentAlignment.TopRight
          StrFormat.LineAlignment = StringAlignment.Near
          StrFormat.Alignment = StringAlignment.Far
      End Select

      Select Case aTextQuality
        Case LybraEnums.TextRendering.SystemDefault
          g.TextRenderingHint = Drawing.Text.TextRenderingHint.SystemDefault
        Case LybraEnums.TextRendering.Antialias
          g.TextRenderingHint = Drawing.Text.TextRenderingHint.AntiAlias
        Case LybraEnums.TextRendering.ClearType
          g.TextRenderingHint = Drawing.Text.TextRenderingHint.ClearTypeGridFit
      End Select

      g.DrawString(aText, _
                   aFont, _
                   New SolidBrush(aSolidBrushColor), _
                   GS.XRectangleF(aPointX, aPointY, aWidth, aHeight), _
                   StrFormat)

    End Sub
#End Region

  End Class
#End Region

End Namespace
