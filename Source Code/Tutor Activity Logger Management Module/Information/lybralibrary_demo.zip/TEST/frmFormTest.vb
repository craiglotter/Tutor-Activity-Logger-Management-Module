Public Class FormTest
  Inherits System.Windows.Forms.Form

#Region " Codice generato da Progettazione Windows Form "

  Public Sub New()
    MyBase.New()

    'Chiamata richiesta da Progettazione Windows Form.
    InitializeComponent()

    'Aggiungere le eventuali istruzioni di inizializzazione dopo la chiamata a InitializeComponent()

  End Sub

  'Form esegue l'override del metodo Dispose per pulire l'elenco dei componenti.
  Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
    If disposing Then
      If Not (components Is Nothing) Then
        components.Dispose()
      End If
    End If
    MyBase.Dispose(disposing)
  End Sub

  'Richiesto da Progettazione Windows Form
  Private components As System.ComponentModel.IContainer

  'NOTA: la procedura che segue � richiesta da Progettazione Windows Form.
  'Pu� essere modificata in Progettazione Windows Form.  
  'Non modificarla nell'editor del codice.
  Friend WithEvents GradientPanelXP1 As Lybra.Forms.Controls.GradientPanelXP
  Friend WithEvents HoverGradientButton21 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton22 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton23 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton24 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverButtonBand5 As Lybra.Forms.Controls.HoverButtonBand
  Friend WithEvents HoverGradientButton16 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton17 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton18 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton26 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton27 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverButtonBand4 As Lybra.Forms.Controls.HoverButtonBand
  Friend WithEvents HoverGradientButton19 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton20 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton25 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverButtonBand2 As Lybra.Forms.Controls.HoverButtonBand
  Friend WithEvents HoverGradientButton6 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton7 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton8 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton9 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton10 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverButtonBand1 As Lybra.Forms.Controls.HoverButtonBand
  Friend WithEvents HoverGradientButton4 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton3 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton2 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton5 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton28 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverButtonBand6 As Lybra.Forms.Controls.HoverButtonBand
  Friend WithEvents HoverGradientButton1 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton29 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton30 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverButtonBand7 As Lybra.Forms.Controls.HoverButtonBand
  Friend WithEvents HoverGradientButton31 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton32 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton33 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton34 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton35 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverButtonBand3 As Lybra.Forms.Controls.HoverButtonBand
  Friend WithEvents HoverGradientButton11 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton12 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton13 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton14 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton15 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton39 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton40 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton41 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton42 As Lybra.Forms.Controls.HoverGradientButton
  Friend WithEvents HoverGradientButton43 As Lybra.Forms.Controls.HoverGradientButton
  <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
    Dim resources As System.Resources.ResourceManager = New System.Resources.ResourceManager(GetType(FormTest))
    Me.GradientPanelXP1 = New Lybra.Forms.Controls.GradientPanelXP
    Me.HoverButtonBand3 = New Lybra.Forms.Controls.HoverButtonBand
    Me.HoverGradientButton11 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton12 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton13 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton14 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton15 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton39 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton40 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton41 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton42 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton43 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton21 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton22 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton23 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton24 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverButtonBand5 = New Lybra.Forms.Controls.HoverButtonBand
    Me.HoverGradientButton16 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton17 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton18 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton26 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton27 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverButtonBand4 = New Lybra.Forms.Controls.HoverButtonBand
    Me.HoverGradientButton19 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton20 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton25 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverButtonBand2 = New Lybra.Forms.Controls.HoverButtonBand
    Me.HoverGradientButton6 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton7 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton8 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton9 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton10 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverButtonBand1 = New Lybra.Forms.Controls.HoverButtonBand
    Me.HoverGradientButton4 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton3 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton2 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton5 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton28 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverButtonBand6 = New Lybra.Forms.Controls.HoverButtonBand
    Me.HoverGradientButton1 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton29 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton30 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverButtonBand7 = New Lybra.Forms.Controls.HoverButtonBand
    Me.HoverGradientButton31 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton32 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton33 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton34 = New Lybra.Forms.Controls.HoverGradientButton
    Me.HoverGradientButton35 = New Lybra.Forms.Controls.HoverGradientButton
    Me.GradientPanelXP1.SuspendLayout()
    Me.HoverButtonBand3.SuspendLayout()
    Me.HoverButtonBand5.SuspendLayout()
    Me.HoverButtonBand4.SuspendLayout()
    Me.HoverButtonBand2.SuspendLayout()
    Me.HoverButtonBand1.SuspendLayout()
    Me.HoverButtonBand6.SuspendLayout()
    Me.HoverButtonBand7.SuspendLayout()
    Me.SuspendLayout()
    '
    'GradientPanelXP1
    '
    Me.GradientPanelXP1.BackColor1 = System.Drawing.Color.DodgerBlue
    Me.GradientPanelXP1.BackColor2 = System.Drawing.Color.RoyalBlue
    Me.GradientPanelXP1.Controls.Add(Me.HoverButtonBand3)
    Me.GradientPanelXP1.Controls.Add(Me.HoverGradientButton21)
    Me.GradientPanelXP1.Controls.Add(Me.HoverGradientButton22)
    Me.GradientPanelXP1.Controls.Add(Me.HoverGradientButton23)
    Me.GradientPanelXP1.Controls.Add(Me.HoverGradientButton24)
    Me.GradientPanelXP1.Controls.Add(Me.HoverButtonBand5)
    Me.GradientPanelXP1.Controls.Add(Me.HoverButtonBand4)
    Me.GradientPanelXP1.Controls.Add(Me.HoverButtonBand2)
    Me.GradientPanelXP1.Controls.Add(Me.HoverButtonBand1)
    Me.GradientPanelXP1.Controls.Add(Me.HoverButtonBand6)
    Me.GradientPanelXP1.Controls.Add(Me.HoverButtonBand7)
    Me.GradientPanelXP1.Dock = System.Windows.Forms.DockStyle.Fill
    Me.GradientPanelXP1.Gradient = System.Drawing.Drawing2D.LinearGradientMode.Vertical
    Me.GradientPanelXP1.Location = New System.Drawing.Point(0, 0)
    Me.GradientPanelXP1.Name = "GradientPanelXP1"
    Me.GradientPanelXP1.Size = New System.Drawing.Size(584, 410)
    Me.GradientPanelXP1.TabIndex = 0
    '
    'HoverButtonBand3
    '
    Me.HoverButtonBand3.AutoArrange = True
    Me.HoverButtonBand3.AutoArrangeDirection = Lybra.Forms.Controls.HoverButtonBand.HowReorder.Vertical
    Me.HoverButtonBand3.Border = True
    Me.HoverButtonBand3.BorderNormalColor = System.Drawing.Color.Red
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton11)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton12)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton13)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton14)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton15)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton39)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton40)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton41)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton42)
    Me.HoverButtonBand3.Controls.Add(Me.HoverGradientButton43)
    Me.HoverButtonBand3.Dock = System.Windows.Forms.DockStyle.Right
    Me.HoverButtonBand3.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal
    Me.HoverButtonBand3.Location = New System.Drawing.Point(552, 28)
    Me.HoverButtonBand3.Name = "HoverButtonBand3"
    Me.HoverButtonBand3.Size = New System.Drawing.Size(32, 354)
    Me.HoverButtonBand3.TabIndex = 64
    '
    'HoverGradientButton11
    '
    Me.HoverGradientButton11.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton11.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal
    Me.HoverGradientButton11.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton11.Image = CType(resources.GetObject("HoverGradientButton11.Image"), System.Drawing.Image)
    Me.HoverGradientButton11.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton11.Location = New System.Drawing.Point(4, 5)
    Me.HoverGradientButton11.Name = "HoverGradientButton11"
    Me.HoverGradientButton11.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton11.TabIndex = 0
    '
    'HoverGradientButton12
    '
    Me.HoverGradientButton12.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton12.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal
    Me.HoverGradientButton12.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton12.Image = CType(resources.GetObject("HoverGradientButton12.Image"), System.Drawing.Image)
    Me.HoverGradientButton12.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton12.Location = New System.Drawing.Point(4, 34)
    Me.HoverGradientButton12.Name = "HoverGradientButton12"
    Me.HoverGradientButton12.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton12.TabIndex = 0
    '
    'HoverGradientButton13
    '
    Me.HoverGradientButton13.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton13.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal
    Me.HoverGradientButton13.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton13.Image = CType(resources.GetObject("HoverGradientButton13.Image"), System.Drawing.Image)
    Me.HoverGradientButton13.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton13.Location = New System.Drawing.Point(4, 63)
    Me.HoverGradientButton13.Name = "HoverGradientButton13"
    Me.HoverGradientButton13.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton13.TabIndex = 0
    '
    'HoverGradientButton14
    '
    Me.HoverGradientButton14.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton14.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal
    Me.HoverGradientButton14.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton14.Image = CType(resources.GetObject("HoverGradientButton14.Image"), System.Drawing.Image)
    Me.HoverGradientButton14.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton14.Location = New System.Drawing.Point(4, 92)
    Me.HoverGradientButton14.Name = "HoverGradientButton14"
    Me.HoverGradientButton14.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton14.TabIndex = 0
    '
    'HoverGradientButton15
    '
    Me.HoverGradientButton15.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton15.GradientMode = System.Drawing.Drawing2D.LinearGradientMode.Horizontal
    Me.HoverGradientButton15.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton15.Image = CType(resources.GetObject("HoverGradientButton15.Image"), System.Drawing.Image)
    Me.HoverGradientButton15.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton15.Location = New System.Drawing.Point(4, 121)
    Me.HoverGradientButton15.Name = "HoverGradientButton15"
    Me.HoverGradientButton15.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton15.TabIndex = 0
    '
    'HoverGradientButton39
    '
    Me.HoverGradientButton39.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton39.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton39.Image = CType(resources.GetObject("HoverGradientButton39.Image"), System.Drawing.Image)
    Me.HoverGradientButton39.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton39.Location = New System.Drawing.Point(4, 150)
    Me.HoverGradientButton39.Name = "HoverGradientButton39"
    Me.HoverGradientButton39.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton39.TabIndex = 0
    '
    'HoverGradientButton40
    '
    Me.HoverGradientButton40.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton40.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton40.Image = CType(resources.GetObject("HoverGradientButton40.Image"), System.Drawing.Image)
    Me.HoverGradientButton40.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton40.Location = New System.Drawing.Point(4, 179)
    Me.HoverGradientButton40.Name = "HoverGradientButton40"
    Me.HoverGradientButton40.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton40.TabIndex = 0
    '
    'HoverGradientButton41
    '
    Me.HoverGradientButton41.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton41.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton41.Image = CType(resources.GetObject("HoverGradientButton41.Image"), System.Drawing.Image)
    Me.HoverGradientButton41.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton41.Location = New System.Drawing.Point(4, 208)
    Me.HoverGradientButton41.Name = "HoverGradientButton41"
    Me.HoverGradientButton41.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton41.TabIndex = 0
    '
    'HoverGradientButton42
    '
    Me.HoverGradientButton42.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton42.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton42.Image = CType(resources.GetObject("HoverGradientButton42.Image"), System.Drawing.Image)
    Me.HoverGradientButton42.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton42.Location = New System.Drawing.Point(4, 237)
    Me.HoverGradientButton42.Name = "HoverGradientButton42"
    Me.HoverGradientButton42.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton42.TabIndex = 0
    '
    'HoverGradientButton43
    '
    Me.HoverGradientButton43.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton43.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton43.Image = CType(resources.GetObject("HoverGradientButton43.Image"), System.Drawing.Image)
    Me.HoverGradientButton43.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton43.Location = New System.Drawing.Point(4, 266)
    Me.HoverGradientButton43.Name = "HoverGradientButton43"
    Me.HoverGradientButton43.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton43.TabIndex = 0
    '
    'HoverGradientButton21
    '
    Me.HoverGradientButton21.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton21.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton21.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton21.Image = CType(resources.GetObject("HoverGradientButton21.Image"), System.Drawing.Image)
    Me.HoverGradientButton21.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton21.Location = New System.Drawing.Point(16, 132)
    Me.HoverGradientButton21.Name = "HoverGradientButton21"
    Me.HoverGradientButton21.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton21.TabIndex = 45
    '
    'HoverGradientButton22
    '
    Me.HoverGradientButton22.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton22.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton22.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton22.Image = CType(resources.GetObject("HoverGradientButton22.Image"), System.Drawing.Image)
    Me.HoverGradientButton22.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton22.Location = New System.Drawing.Point(16, 192)
    Me.HoverGradientButton22.Name = "HoverGradientButton22"
    Me.HoverGradientButton22.Selected = True
    Me.HoverGradientButton22.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton22.TabIndex = 46
    '
    'HoverGradientButton23
    '
    Me.HoverGradientButton23.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton23.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton23.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton23.Image = CType(resources.GetObject("HoverGradientButton23.Image"), System.Drawing.Image)
    Me.HoverGradientButton23.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton23.Location = New System.Drawing.Point(16, 252)
    Me.HoverGradientButton23.Name = "HoverGradientButton23"
    Me.HoverGradientButton23.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton23.TabIndex = 43
    '
    'HoverGradientButton24
    '
    Me.HoverGradientButton24.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton24.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton24.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton24.Image = CType(resources.GetObject("HoverGradientButton24.Image"), System.Drawing.Image)
    Me.HoverGradientButton24.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton24.Location = New System.Drawing.Point(16, 312)
    Me.HoverGradientButton24.Name = "HoverGradientButton24"
    Me.HoverGradientButton24.Selected = True
    Me.HoverGradientButton24.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton24.TabIndex = 44
    '
    'HoverButtonBand5
    '
    Me.HoverButtonBand5.AutoArrange = True
    Me.HoverButtonBand5.AutoArrangeAlignment = Lybra.Forms.Controls.HoverButtonBand.HowAlign.Center
    Me.HoverButtonBand5.AutoArrangMargin = 15
    Me.HoverButtonBand5.Controls.Add(Me.HoverGradientButton16)
    Me.HoverButtonBand5.Controls.Add(Me.HoverGradientButton17)
    Me.HoverButtonBand5.Controls.Add(Me.HoverGradientButton18)
    Me.HoverButtonBand5.Controls.Add(Me.HoverGradientButton26)
    Me.HoverButtonBand5.Controls.Add(Me.HoverGradientButton27)
    Me.HoverButtonBand5.Location = New System.Drawing.Point(92, 312)
    Me.HoverButtonBand5.Name = "HoverButtonBand5"
    Me.HoverButtonBand5.Size = New System.Drawing.Size(176, 32)
    Me.HoverButtonBand5.TabIndex = 42
    '
    'HoverGradientButton16
    '
    Me.HoverGradientButton16.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton16.BorderHover = True
    Me.HoverGradientButton16.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton16.BorderNormal = True
    Me.HoverGradientButton16.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton16.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton16.Image = CType(resources.GetObject("HoverGradientButton16.Image"), System.Drawing.Image)
    Me.HoverGradientButton16.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton16.Location = New System.Drawing.Point(15, 4)
    Me.HoverGradientButton16.Name = "HoverGradientButton16"
    Me.HoverGradientButton16.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton16.TabIndex = 0
    '
    'HoverGradientButton17
    '
    Me.HoverGradientButton17.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton17.BorderHover = True
    Me.HoverGradientButton17.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton17.BorderNormal = True
    Me.HoverGradientButton17.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton17.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton17.Image = CType(resources.GetObject("HoverGradientButton17.Image"), System.Drawing.Image)
    Me.HoverGradientButton17.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton17.Location = New System.Drawing.Point(46, 4)
    Me.HoverGradientButton17.Name = "HoverGradientButton17"
    Me.HoverGradientButton17.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton17.TabIndex = 0
    '
    'HoverGradientButton18
    '
    Me.HoverGradientButton18.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton18.BorderHover = True
    Me.HoverGradientButton18.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton18.BorderNormal = True
    Me.HoverGradientButton18.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton18.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton18.Image = CType(resources.GetObject("HoverGradientButton18.Image"), System.Drawing.Image)
    Me.HoverGradientButton18.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton18.Location = New System.Drawing.Point(77, 4)
    Me.HoverGradientButton18.Name = "HoverGradientButton18"
    Me.HoverGradientButton18.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton18.TabIndex = 0
    '
    'HoverGradientButton26
    '
    Me.HoverGradientButton26.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton26.BorderHover = True
    Me.HoverGradientButton26.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton26.BorderNormal = True
    Me.HoverGradientButton26.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton26.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton26.Image = CType(resources.GetObject("HoverGradientButton26.Image"), System.Drawing.Image)
    Me.HoverGradientButton26.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton26.Location = New System.Drawing.Point(108, 4)
    Me.HoverGradientButton26.Name = "HoverGradientButton26"
    Me.HoverGradientButton26.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton26.TabIndex = 0
    '
    'HoverGradientButton27
    '
    Me.HoverGradientButton27.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton27.BorderHover = True
    Me.HoverGradientButton27.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton27.BorderNormal = True
    Me.HoverGradientButton27.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton27.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton27.Image = CType(resources.GetObject("HoverGradientButton27.Image"), System.Drawing.Image)
    Me.HoverGradientButton27.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton27.Location = New System.Drawing.Point(139, 4)
    Me.HoverGradientButton27.Name = "HoverGradientButton27"
    Me.HoverGradientButton27.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton27.TabIndex = 0
    '
    'HoverButtonBand4
    '
    Me.HoverButtonBand4.AutoArrangMargin = 20
    Me.HoverButtonBand4.Controls.Add(Me.HoverGradientButton19)
    Me.HoverButtonBand4.Controls.Add(Me.HoverGradientButton20)
    Me.HoverButtonBand4.Controls.Add(Me.HoverGradientButton25)
    Me.HoverButtonBand4.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
    Me.HoverButtonBand4.Location = New System.Drawing.Point(291, 148)
    Me.HoverButtonBand4.Name = "HoverButtonBand4"
    Me.HoverButtonBand4.Size = New System.Drawing.Size(176, 72)
    Me.HoverButtonBand4.TabIndex = 40
    Me.HoverButtonBand4.Text = "Option set"
    Me.HoverButtonBand4.TextAlign = System.Drawing.ContentAlignment.TopLeft
    '
    'HoverGradientButton19
    '
    Me.HoverGradientButton19.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton19.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverOption
    Me.HoverGradientButton19.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton19.Image = CType(resources.GetObject("HoverGradientButton19.Image"), System.Drawing.Image)
    Me.HoverGradientButton19.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton19.ImageSelected = CType(resources.GetObject("HoverGradientButton19.ImageSelected"), System.Drawing.Image)
    Me.HoverGradientButton19.Location = New System.Drawing.Point(23, 16)
    Me.HoverGradientButton19.Name = "HoverGradientButton19"
    Me.HoverGradientButton19.OptionGroup = 1
    Me.HoverGradientButton19.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton19.TabIndex = 7
    '
    'HoverGradientButton20
    '
    Me.HoverGradientButton20.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton20.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverOption
    Me.HoverGradientButton20.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton20.Image = CType(resources.GetObject("HoverGradientButton20.Image"), System.Drawing.Image)
    Me.HoverGradientButton20.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton20.ImageSelected = CType(resources.GetObject("HoverGradientButton20.ImageSelected"), System.Drawing.Image)
    Me.HoverGradientButton20.Location = New System.Drawing.Point(68, 16)
    Me.HoverGradientButton20.Name = "HoverGradientButton20"
    Me.HoverGradientButton20.OptionGroup = 1
    Me.HoverGradientButton20.Selected = True
    Me.HoverGradientButton20.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton20.TabIndex = 6
    '
    'HoverGradientButton25
    '
    Me.HoverGradientButton25.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton25.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverOption
    Me.HoverGradientButton25.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton25.Image = CType(resources.GetObject("HoverGradientButton25.Image"), System.Drawing.Image)
    Me.HoverGradientButton25.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton25.ImageSelected = CType(resources.GetObject("HoverGradientButton25.ImageSelected"), System.Drawing.Image)
    Me.HoverGradientButton25.Location = New System.Drawing.Point(113, 16)
    Me.HoverGradientButton25.Name = "HoverGradientButton25"
    Me.HoverGradientButton25.OptionGroup = 1
    Me.HoverGradientButton25.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton25.TabIndex = 5
    '
    'HoverButtonBand2
    '
    Me.HoverButtonBand2.AutoArrange = True
    Me.HoverButtonBand2.AutoArrangMargin = 20
    Me.HoverButtonBand2.Controls.Add(Me.HoverGradientButton6)
    Me.HoverButtonBand2.Controls.Add(Me.HoverGradientButton7)
    Me.HoverButtonBand2.Controls.Add(Me.HoverGradientButton8)
    Me.HoverButtonBand2.Controls.Add(Me.HoverGradientButton9)
    Me.HoverButtonBand2.Controls.Add(Me.HoverGradientButton10)
    Me.HoverButtonBand2.Location = New System.Drawing.Point(11, 48)
    Me.HoverButtonBand2.Name = "HoverButtonBand2"
    Me.HoverButtonBand2.Size = New System.Drawing.Size(456, 72)
    Me.HoverButtonBand2.TabIndex = 38
    '
    'HoverGradientButton6
    '
    Me.HoverGradientButton6.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton6.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton6.Image = CType(resources.GetObject("HoverGradientButton6.Image"), System.Drawing.Image)
    Me.HoverGradientButton6.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton6.Location = New System.Drawing.Point(20, 16)
    Me.HoverGradientButton6.Name = "HoverGradientButton6"
    Me.HoverGradientButton6.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton6.TabIndex = 0
    '
    'HoverGradientButton7
    '
    Me.HoverGradientButton7.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton7.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton7.Image = CType(resources.GetObject("HoverGradientButton7.Image"), System.Drawing.Image)
    Me.HoverGradientButton7.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton7.Location = New System.Drawing.Point(65, 16)
    Me.HoverGradientButton7.Name = "HoverGradientButton7"
    Me.HoverGradientButton7.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton7.TabIndex = 0
    '
    'HoverGradientButton8
    '
    Me.HoverGradientButton8.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton8.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton8.Image = CType(resources.GetObject("HoverGradientButton8.Image"), System.Drawing.Image)
    Me.HoverGradientButton8.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton8.Location = New System.Drawing.Point(110, 16)
    Me.HoverGradientButton8.Name = "HoverGradientButton8"
    Me.HoverGradientButton8.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton8.TabIndex = 0
    Me.HoverGradientButton8.ToolTipActive = True
    Me.HoverGradientButton8.ToolTipText = "Send email to the user"
    '
    'HoverGradientButton9
    '
    Me.HoverGradientButton9.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton9.BorderHover = True
    Me.HoverGradientButton9.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton9.BorderNormal = True
    Me.HoverGradientButton9.ForeColor = System.Drawing.Color.Blue
    Me.HoverGradientButton9.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton9.Image = CType(resources.GetObject("HoverGradientButton9.Image"), System.Drawing.Image)
    Me.HoverGradientButton9.Location = New System.Drawing.Point(155, 16)
    Me.HoverGradientButton9.Name = "HoverGradientButton9"
    Me.HoverGradientButton9.Size = New System.Drawing.Size(141, 40)
    Me.HoverGradientButton9.TabIndex = 0
    Me.HoverGradientButton9.Text = "Back Home"
    Me.HoverGradientButton9.ToolTipActive = True
    Me.HoverGradientButton9.ToolTipText = "Return to Home Page"
    '
    'HoverGradientButton10
    '
    Me.HoverGradientButton10.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton10.BorderHover = True
    Me.HoverGradientButton10.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton10.BorderNormal = True
    Me.HoverGradientButton10.ForeColor = System.Drawing.Color.Blue
    Me.HoverGradientButton10.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton10.Image = CType(resources.GetObject("HoverGradientButton10.Image"), System.Drawing.Image)
    Me.HoverGradientButton10.Location = New System.Drawing.Point(301, 16)
    Me.HoverGradientButton10.Name = "HoverGradientButton10"
    Me.HoverGradientButton10.Size = New System.Drawing.Size(140, 40)
    Me.HoverGradientButton10.TabIndex = 0
    Me.HoverGradientButton10.Text = "Add user"
    Me.HoverGradientButton10.ToolTipActive = True
    Me.HoverGradientButton10.ToolTipText = "Add a new user"
    '
    'HoverButtonBand1
    '
    Me.HoverButtonBand1.AutoArrange = True
    Me.HoverButtonBand1.Controls.Add(Me.HoverGradientButton4)
    Me.HoverButtonBand1.Controls.Add(Me.HoverGradientButton3)
    Me.HoverButtonBand1.Controls.Add(Me.HoverGradientButton2)
    Me.HoverButtonBand1.Controls.Add(Me.HoverGradientButton5)
    Me.HoverButtonBand1.Controls.Add(Me.HoverGradientButton28)
    Me.HoverButtonBand1.Dock = System.Windows.Forms.DockStyle.Top
    Me.HoverButtonBand1.Location = New System.Drawing.Point(0, 0)
    Me.HoverButtonBand1.Name = "HoverButtonBand1"
    Me.HoverButtonBand1.Size = New System.Drawing.Size(584, 28)
    Me.HoverButtonBand1.TabIndex = 37
    '
    'HoverGradientButton4
    '
    Me.HoverGradientButton4.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton4.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton4.Image = CType(resources.GetObject("HoverGradientButton4.Image"), System.Drawing.Image)
    Me.HoverGradientButton4.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton4.Location = New System.Drawing.Point(5, 2)
    Me.HoverGradientButton4.Name = "HoverGradientButton4"
    Me.HoverGradientButton4.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton4.TabIndex = 0
    '
    'HoverGradientButton3
    '
    Me.HoverGradientButton3.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton3.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton3.Image = CType(resources.GetObject("HoverGradientButton3.Image"), System.Drawing.Image)
    Me.HoverGradientButton3.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton3.Location = New System.Drawing.Point(34, 2)
    Me.HoverGradientButton3.Name = "HoverGradientButton3"
    Me.HoverGradientButton3.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton3.TabIndex = 0
    '
    'HoverGradientButton2
    '
    Me.HoverGradientButton2.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton2.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton2.Image = CType(resources.GetObject("HoverGradientButton2.Image"), System.Drawing.Image)
    Me.HoverGradientButton2.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton2.Location = New System.Drawing.Point(63, 2)
    Me.HoverGradientButton2.Name = "HoverGradientButton2"
    Me.HoverGradientButton2.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton2.TabIndex = 0
    '
    'HoverGradientButton5
    '
    Me.HoverGradientButton5.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton5.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton5.Image = CType(resources.GetObject("HoverGradientButton5.Image"), System.Drawing.Image)
    Me.HoverGradientButton5.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton5.Location = New System.Drawing.Point(92, 2)
    Me.HoverGradientButton5.Name = "HoverGradientButton5"
    Me.HoverGradientButton5.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton5.TabIndex = 0
    '
    'HoverGradientButton28
    '
    Me.HoverGradientButton28.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton28.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton28.Image = CType(resources.GetObject("HoverGradientButton28.Image"), System.Drawing.Image)
    Me.HoverGradientButton28.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton28.Location = New System.Drawing.Point(121, 2)
    Me.HoverGradientButton28.Name = "HoverGradientButton28"
    Me.HoverGradientButton28.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton28.TabIndex = 0
    '
    'HoverButtonBand6
    '
    Me.HoverButtonBand6.AutoArrangMargin = 20
    Me.HoverButtonBand6.Controls.Add(Me.HoverGradientButton1)
    Me.HoverButtonBand6.Controls.Add(Me.HoverGradientButton29)
    Me.HoverButtonBand6.Controls.Add(Me.HoverGradientButton30)
    Me.HoverButtonBand6.ForeColor = System.Drawing.Color.FromArgb(CType(0, Byte), CType(0, Byte), CType(192, Byte))
    Me.HoverButtonBand6.Location = New System.Drawing.Point(291, 244)
    Me.HoverButtonBand6.Name = "HoverButtonBand6"
    Me.HoverButtonBand6.Size = New System.Drawing.Size(176, 72)
    Me.HoverButtonBand6.TabIndex = 41
    Me.HoverButtonBand6.Text = "Checkbox"
    Me.HoverButtonBand6.TextAlign = System.Drawing.ContentAlignment.TopLeft
    '
    'HoverGradientButton1
    '
    Me.HoverGradientButton1.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton1.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton1.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton1.Image = CType(resources.GetObject("HoverGradientButton1.Image"), System.Drawing.Image)
    Me.HoverGradientButton1.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton1.ImageSelected = CType(resources.GetObject("HoverGradientButton1.ImageSelected"), System.Drawing.Image)
    Me.HoverGradientButton1.Location = New System.Drawing.Point(23, 16)
    Me.HoverGradientButton1.Name = "HoverGradientButton1"
    Me.HoverGradientButton1.OptionGroup = 1
    Me.HoverGradientButton1.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton1.TabIndex = 7
    '
    'HoverGradientButton29
    '
    Me.HoverGradientButton29.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton29.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton29.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton29.Image = CType(resources.GetObject("HoverGradientButton29.Image"), System.Drawing.Image)
    Me.HoverGradientButton29.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton29.ImageSelected = CType(resources.GetObject("HoverGradientButton29.ImageSelected"), System.Drawing.Image)
    Me.HoverGradientButton29.Location = New System.Drawing.Point(68, 16)
    Me.HoverGradientButton29.Name = "HoverGradientButton29"
    Me.HoverGradientButton29.OptionGroup = 1
    Me.HoverGradientButton29.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton29.TabIndex = 6
    '
    'HoverGradientButton30
    '
    Me.HoverGradientButton30.BackColor2 = System.Drawing.Color.FromArgb(CType(129, Byte), CType(169, Byte), CType(226, Byte))
    Me.HoverGradientButton30.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton30.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton30.Image = CType(resources.GetObject("HoverGradientButton30.Image"), System.Drawing.Image)
    Me.HoverGradientButton30.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton30.ImageSelected = CType(resources.GetObject("HoverGradientButton30.ImageSelected"), System.Drawing.Image)
    Me.HoverGradientButton30.Location = New System.Drawing.Point(113, 16)
    Me.HoverGradientButton30.Name = "HoverGradientButton30"
    Me.HoverGradientButton30.OptionGroup = 1
    Me.HoverGradientButton30.Size = New System.Drawing.Size(40, 40)
    Me.HoverGradientButton30.TabIndex = 5
    '
    'HoverButtonBand7
    '
    Me.HoverButtonBand7.AutoArrange = True
    Me.HoverButtonBand7.AutoArrangMargin = 15
    Me.HoverButtonBand7.BackColor1 = System.Drawing.Color.LightGray
    Me.HoverButtonBand7.BackColor2 = System.Drawing.Color.DarkGray
    Me.HoverButtonBand7.Controls.Add(Me.HoverGradientButton31)
    Me.HoverButtonBand7.Controls.Add(Me.HoverGradientButton32)
    Me.HoverButtonBand7.Controls.Add(Me.HoverGradientButton33)
    Me.HoverButtonBand7.Controls.Add(Me.HoverGradientButton34)
    Me.HoverButtonBand7.Controls.Add(Me.HoverGradientButton35)
    Me.HoverButtonBand7.Dock = System.Windows.Forms.DockStyle.Bottom
    Me.HoverButtonBand7.Location = New System.Drawing.Point(0, 382)
    Me.HoverButtonBand7.Name = "HoverButtonBand7"
    Me.HoverButtonBand7.Size = New System.Drawing.Size(584, 28)
    Me.HoverButtonBand7.TabIndex = 42
    '
    'HoverGradientButton31
    '
    Me.HoverGradientButton31.BackColor1 = System.Drawing.Color.LightGray
    Me.HoverGradientButton31.BackColor2 = System.Drawing.Color.DarkGray
    Me.HoverGradientButton31.BorderHover = True
    Me.HoverGradientButton31.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton31.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton31.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton31.Image = CType(resources.GetObject("HoverGradientButton31.Image"), System.Drawing.Image)
    Me.HoverGradientButton31.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton31.Location = New System.Drawing.Point(15, 2)
    Me.HoverGradientButton31.Name = "HoverGradientButton31"
    Me.HoverGradientButton31.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton31.TabIndex = 0
    '
    'HoverGradientButton32
    '
    Me.HoverGradientButton32.BackColor1 = System.Drawing.Color.LightGray
    Me.HoverGradientButton32.BackColor2 = System.Drawing.Color.DarkGray
    Me.HoverGradientButton32.BorderHover = True
    Me.HoverGradientButton32.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton32.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton32.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton32.Image = CType(resources.GetObject("HoverGradientButton32.Image"), System.Drawing.Image)
    Me.HoverGradientButton32.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton32.Location = New System.Drawing.Point(44, 2)
    Me.HoverGradientButton32.Name = "HoverGradientButton32"
    Me.HoverGradientButton32.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton32.TabIndex = 0
    '
    'HoverGradientButton33
    '
    Me.HoverGradientButton33.BackColor1 = System.Drawing.Color.LightGray
    Me.HoverGradientButton33.BackColor2 = System.Drawing.Color.DarkGray
    Me.HoverGradientButton33.BorderHover = True
    Me.HoverGradientButton33.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton33.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton33.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton33.Image = CType(resources.GetObject("HoverGradientButton33.Image"), System.Drawing.Image)
    Me.HoverGradientButton33.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton33.Location = New System.Drawing.Point(73, 2)
    Me.HoverGradientButton33.Name = "HoverGradientButton33"
    Me.HoverGradientButton33.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton33.TabIndex = 0
    '
    'HoverGradientButton34
    '
    Me.HoverGradientButton34.BackColor1 = System.Drawing.Color.LightGray
    Me.HoverGradientButton34.BackColor2 = System.Drawing.Color.DarkGray
    Me.HoverGradientButton34.BorderHover = True
    Me.HoverGradientButton34.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton34.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton34.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton34.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton34.Image = CType(resources.GetObject("HoverGradientButton34.Image"), System.Drawing.Image)
    Me.HoverGradientButton34.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton34.Location = New System.Drawing.Point(102, 2)
    Me.HoverGradientButton34.Name = "HoverGradientButton34"
    Me.HoverGradientButton34.Selected = True
    Me.HoverGradientButton34.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton34.TabIndex = 0
    '
    'HoverGradientButton35
    '
    Me.HoverGradientButton35.BackColor1 = System.Drawing.Color.LightGray
    Me.HoverGradientButton35.BackColor2 = System.Drawing.Color.DarkGray
    Me.HoverGradientButton35.BorderHover = True
    Me.HoverGradientButton35.BorderHoverColor = System.Drawing.Color.Red
    Me.HoverGradientButton35.BorderNormalColor = System.Drawing.Color.Blue
    Me.HoverGradientButton35.ButtonType = Lybra.Forms.Controls.HoverGradientButton.HoverButtonType.HoverCheck
    Me.HoverGradientButton35.HoverForeColor = System.Drawing.Color.Empty
    Me.HoverGradientButton35.Image = CType(resources.GetObject("HoverGradientButton35.Image"), System.Drawing.Image)
    Me.HoverGradientButton35.ImageAlign = System.Drawing.ContentAlignment.MiddleCenter
    Me.HoverGradientButton35.Location = New System.Drawing.Point(131, 2)
    Me.HoverGradientButton35.Name = "HoverGradientButton35"
    Me.HoverGradientButton35.Selected = True
    Me.HoverGradientButton35.Size = New System.Drawing.Size(24, 24)
    Me.HoverGradientButton35.TabIndex = 0
    '
    'FormTest
    '
    Me.AutoScaleBaseSize = New System.Drawing.Size(5, 13)
    Me.ClientSize = New System.Drawing.Size(584, 410)
    Me.Controls.Add(Me.GradientPanelXP1)
    Me.Name = "FormTest"
    Me.Text = "FormTest"
    Me.GradientPanelXP1.ResumeLayout(False)
    Me.HoverButtonBand3.ResumeLayout(False)
    Me.HoverButtonBand5.ResumeLayout(False)
    Me.HoverButtonBand4.ResumeLayout(False)
    Me.HoverButtonBand2.ResumeLayout(False)
    Me.HoverButtonBand1.ResumeLayout(False)
    Me.HoverButtonBand6.ResumeLayout(False)
    Me.HoverButtonBand7.ResumeLayout(False)
    Me.ResumeLayout(False)

  End Sub

#End Region

End Class
