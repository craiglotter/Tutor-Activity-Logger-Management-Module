Namespace Lybra.Forms.Controls

  Public Class LybraEnums

    Public Enum TextRendering As Integer
      SystemDefault = 0
      Antialias = 1
      ClearType = 2
    End Enum

  End Class

End Namespace

