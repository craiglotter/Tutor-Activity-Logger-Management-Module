Namespace Lybra.Forms.Controls

  <Designer("System.Windows.Forms.Design.ParentControlDesigner, System.Design", _
              GetType(IDesigner)), DefaultEvent("Click"), DefaultProperty("Text")> _
  Public Class GradientPanelXP
    Inherits System.Windows.Forms.Panel

    Private mBackColor1 As Color = Color.FromArgb(221, 236, 254)
    Private mBackColor2 As Color = Color.FromArgb(129, 169, 226)
    Private mGradient As Drawing2D.LinearGradientMode = Drawing2D.LinearGradientMode.Vertical

#Region " Component Designer generated code "

    Public Sub New()
      MyBase.New()

      ' This call is required by the Component Designer.
      InitializeComponent()

      'Add any initialization after the InitializeComponent() call

      ' This draws the control whenever it is resized
      setstyle(ControlStyles.ResizeRedraw, True)

      ' This supports mouse movement such as the mouse wheel
      setstyle(ControlStyles.UserMouse, True)

      ' This allows the control to be transparent
      setstyle(ControlStyles.SupportsTransparentBackColor, True)

      ' This helps with drawing the control so that it doesn't flicker
      Me.SetStyle(ControlStyles.DoubleBuffer _
        Or ControlStyles.UserPaint _
        Or ControlStyles.AllPaintingInWmPaint, _
        True)

      ' This updates the styles
      Me.UpdateStyles()

    End Sub

    Protected Overloads Overrides Sub Dispose(ByVal disposing As Boolean)
      If disposing Then
        If Not (components Is Nothing) Then
          components.Dispose()
        End If
      End If
      MyBase.Dispose(disposing)
    End Sub

    Private components As System.ComponentModel.IContainer

    <System.Diagnostics.DebuggerStepThrough()> Private Sub InitializeComponent()
      components = New System.ComponentModel.Container
    End Sub

#End Region

#Region "Public Properties"
    <Browsable(True), DefaultValue(GetType(Color), "InactiveCaptionText")> _
     Public Property BackColor1() As Color
      Get
        Return mBackColor1
      End Get
      Set(ByVal value As Color)
        mBackColor1 = value
      End Set
    End Property

    <Browsable(True), DefaultValue(GetType(Color), "InactiveCaption")> _
      Public Property BackColor2() As Color
      Get
        Return mBackColor2
      End Get
      Set(ByVal value As Color)
        mBackColor2 = value
      End Set
    End Property

    <Browsable(True), DefaultValue(GetType(Drawing2D.LinearGradientMode), "ForwardDiagonal")> _
    Public Property Gradient() As Drawing2D.LinearGradientMode
      Get
        Return mGradient
      End Get
      Set(ByVal value As Drawing2D.LinearGradientMode)
        mGradient = value
      End Set
    End Property

#End Region

    <Browsable(False)> _
    Friend ReadOnly Property WorkspaceRect() As Rectangle
      Get
        Return New Rectangle(0, 0, Me.Width - 1, Me.Height - 1)
      End Get
    End Property

    Protected Overrides Sub OnPaint(ByVal e As System.Windows.Forms.PaintEventArgs)
      If Me.Width > 0 Or Me.Height > 0 Then
        Dim rectPaint As RectangleF = New RectangleF(0, 0, Me.Width, Me.Height)
        Dim gradBrush As New System.Drawing.Drawing2D.LinearGradientBrush(rectPaint, mBackColor1, mBackColor2, mGradient)

        e.Graphics.FillRectangle(gradBrush, rectPaint)
      End If
      MyBase.OnPaint(e)
    End Sub

    Protected Overrides Sub OnResize(ByVal eventargs As System.EventArgs)
      MyBase.OnResize(eventargs)
      Me.Invalidate()
    End Sub

  End Class

End Namespace